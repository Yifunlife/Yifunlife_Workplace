-- Schema only. No customers, passwords, orders or images.
CREATE TABLE workplace_migrations(name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE `catalog_categories` (
	`id` text PRIMARY KEY NOT NULL,
	`level` integer NOT NULL,
	`parent_key` text DEFAULT '' NOT NULL,
	`name` text NOT NULL,
	`created_at` text DEFAULT '' NOT NULL
);
CREATE TABLE `product_overrides` (
	`product_id` text PRIMARY KEY NOT NULL,
	`name` text,
	`price` text,
	`image_url` text,
	`category_1` text,
	`category_2` text,
	`category_3` text,
	`color_tag` text,
	`has_screen` integer DEFAULT false NOT NULL,
	`is_recommended` integer DEFAULT false NOT NULL,
	`updated_at` text DEFAULT '' NOT NULL
, `volume` text, `major_category` text, `stock` integer, `specification` text, `unit` text, `cost` real, `supply_method` text, `branch_price` real);
CREATE TABLE `product_recommendations` (
	`product_id` text NOT NULL,
	`related_product_id` text NOT NULL, `quantity` integer DEFAULT 1 NOT NULL,
	PRIMARY KEY(`product_id`, `related_product_id`)
);
CREATE TABLE `login_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`expires_at` text NOT NULL
);
CREATE TABLE `kitchen_packages` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`config_json` text NOT NULL,
	`updated_at` text DEFAULT '' NOT NULL
);
CREATE TABLE `catalog_products` (
	`id` text PRIMARY KEY NOT NULL,
	`sku` text NOT NULL,
	`name` text NOT NULL,
	`english_name` text DEFAULT '' NOT NULL,
	`category` text DEFAULT '' NOT NULL,
	`family` text DEFAULT '' NOT NULL,
	`price` real,
	`price_note` text DEFAULT '' NOT NULL,
	`usd_price` real,
	`unit` text DEFAULT '' NOT NULL,
	`specification` text DEFAULT '' NOT NULL,
	`brand` text DEFAULT '' NOT NULL,
	`material` text DEFAULT '' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`image_key` text DEFAULT '' NOT NULL
, `factory_price` real, `vip_price` real);
CREATE TABLE `area_pairing_rules` (
  `area` text PRIMARY KEY NOT NULL,
  `config_json` text NOT NULL,
  `updated_at` text DEFAULT '' NOT NULL
);
CREATE TABLE `app_users` (
  `email` text PRIMARY KEY NOT NULL,
  `name` text NOT NULL,
  `password_hash` text NOT NULL,
  `password_salt` text NOT NULL,
  `role` text DEFAULT 'employee' NOT NULL,
  `status` text DEFAULT 'pending' NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL
);
CREATE TABLE `password_reset_tokens` (
  `token_hash` text PRIMARY KEY NOT NULL,
  `email` text NOT NULL,
  `expires_at` text NOT NULL,
  `created_at` text NOT NULL
);
CREATE TABLE `quotation_history` (
	`id` text PRIMARY KEY NOT NULL,
	`contract_no` text NOT NULL,
	`project_name` text NOT NULL,
	`generated_at` text NOT NULL
, `created_by` text NOT NULL DEFAULT '', `snapshot_json` text, `is_finalized` integer NOT NULL DEFAULT 0, `archived_at` text, `lineage_id` text, `project_status` text NOT NULL DEFAULT 'quoted', `status_updated_at` text NOT NULL DEFAULT '', `customer_name` text NOT NULL DEFAULT '', `last_follow_up_at` text NOT NULL DEFAULT '', `quote_valid_until` text NOT NULL DEFAULT '', `loss_reason` text NOT NULL DEFAULT '', `loss_note` text NOT NULL DEFAULT '', `next_follow_up_at` text NOT NULL DEFAULT '', final_amount real, final_currency text, confirmed_at text, confirmed_by text NOT NULL DEFAULT '', voided_at text, voided_by text NOT NULL DEFAULT '', void_reason text NOT NULL DEFAULT '', project_id TEXT REFERENCES projects(id), document_type TEXT NOT NULL DEFAULT 'original', parent_order_id TEXT, ordered_at TEXT);
CREATE TABLE `product_classifications` (
	`id` text PRIMARY KEY NOT NULL,
	`product_id` text NOT NULL,
	`level_1` text NOT NULL,
	`level_2` text NOT NULL,
	`level_3` text NOT NULL,
	`created_at` text DEFAULT '' NOT NULL,
	`updated_at` text DEFAULT '' NOT NULL
);
CREATE TABLE `product_tags` (
	`product_id` text NOT NULL,
	`tag` text NOT NULL,
	PRIMARY KEY(`product_id`, `tag`)
);
CREATE TABLE `toy_matching_drafts` (
  `id` text PRIMARY KEY NOT NULL,
  `created_by` text NOT NULL,
  `name` text NOT NULL,
  `snapshot_json` text NOT NULL,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL
, project_id TEXT REFERENCES projects(id));
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('purchaser', 'supplier')),
  supplier_id TEXT,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE suppliers (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_info TEXT NOT NULL,
  purchaser_name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
, region TEXT NOT NULL DEFAULT '', payment_account TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', archived_at TEXT, is_online_purchase INTEGER NOT NULL DEFAULT 0 CHECK(is_online_purchase IN (0, 1)));
CREATE TABLE purchase_orders (
  id TEXT PRIMARY KEY,
  po_number TEXT NOT NULL UNIQUE,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id),
  project_name TEXT NOT NULL,
  order_date TEXT NOT NULL,
  required_ship_date TEXT NOT NULL,
  promised_ship_date TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending_confirmation', 'in_production', 'ready_to_ship', 'shipped', 'received', 'completed')),
  purchaser_name TEXT NOT NULL,
  internal_requirements TEXT NOT NULL DEFAULT '',
  production_progress INTEGER NOT NULL DEFAULT 0 CHECK (production_progress BETWEEN 0 AND 100),
  production_note TEXT NOT NULL DEFAULT '',
  carrier TEXT NOT NULL DEFAULT '',
  tracking_number TEXT NOT NULL DEFAULT '',
  shipped_at TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
, shipment_status TEXT NOT NULL DEFAULT 'none'
  CHECK (shipment_status IN ('none', 'partial', 'complete')), archived_at TEXT, estimated_ship_date TEXT, delivery_revision INTEGER NOT NULL DEFAULT 0, delivery_actor_id TEXT REFERENCES users(id), delivery_actor_name TEXT NOT NULL DEFAULT '', delivery_change_reason TEXT NOT NULL DEFAULT '', commercial_terms_json TEXT, commercial_status TEXT NOT NULL DEFAULT 'unverified' CHECK(commercial_status IN ('unverified', 'confirmed')), commercial_revision INTEGER NOT NULL DEFAULT 0, commercial_change_id TEXT);
CREATE TABLE order_items (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  product_type TEXT NOT NULL CHECK (product_type IN ('配件类', '电气类', '安全防护类', '成品设备类', '定制加工类')),
  quantity REAL NOT NULL CHECK (quantity > 0),
  unit_price REAL NOT NULL CHECK (unit_price >= 0),
  amount REAL NOT NULL CHECK (amount >= 0),
  specification TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
, unit TEXT NOT NULL DEFAULT '', production_completed INTEGER NOT NULL DEFAULT 0 CHECK (production_completed IN (0, 1)), production_completed_at TEXT, production_completed_by TEXT, model TEXT NOT NULL DEFAULT '', completion_date TEXT, workflow_stage TEXT NOT NULL DEFAULT 'queued'
  CHECK (workflow_stage IN ('queued', 'in_production', 'production_complete', 'ready_to_ship', 'shipment_complete')), shipped_quantity INTEGER NOT NULL DEFAULT 0 CHECK (shipped_quantity >= 0 AND shipped_quantity <= quantity), acceptance_status TEXT NOT NULL DEFAULT 'pending' CHECK (acceptance_status IN ('pending','approved','rejected')), production_revision INTEGER NOT NULL DEFAULT 0, material_process TEXT NOT NULL DEFAULT '', installation_method TEXT NOT NULL DEFAULT '', received_at TEXT, received_by TEXT, stocked_at TEXT, stocked_by TEXT, received_quantity INTEGER NOT NULL DEFAULT 0, stocked_quantity INTEGER NOT NULL DEFAULT 0, freight_payment_status TEXT NOT NULL DEFAULT 'unknown' CHECK(freight_payment_status IN ('unknown','paid','unpaid')), freight_payment_revision INTEGER NOT NULL DEFAULT 0, freight_payment_by TEXT REFERENCES users(id), freight_payment_at TEXT, color TEXT NOT NULL DEFAULT '', packaging_volume TEXT NOT NULL DEFAULT '', packaging_volume_revision INTEGER NOT NULL DEFAULT 0, packaging_volume_by TEXT REFERENCES users(id), packaging_volume_at TEXT, production_photo_waived INTEGER NOT NULL DEFAULT 0 CHECK (production_photo_waived IN (0, 1)), product_category TEXT NOT NULL DEFAULT '', product_id TEXT REFERENCES products(id), baseline_line_id TEXT REFERENCES baseline_lines(id));
CREATE TABLE attachments (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  item_id TEXT REFERENCES order_items(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('purchase_order', 'product_image', 'production_photo', 'shipment_photo')),
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  r2_key TEXT NOT NULL UNIQUE,
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
, deleted_at TEXT, deleted_by TEXT REFERENCES users(id), purpose TEXT CHECK(purpose IS NULL OR purpose='scene'));
CREATE TABLE order_events (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  actor_id TEXT NOT NULL REFERENCES users(id),
  actor_name TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE auth_attempts (
  key TEXT PRIMARY KEY,
  attempt_count INTEGER NOT NULL,
  window_started_at TEXT NOT NULL,
  locked_until TEXT,
  updated_at TEXT NOT NULL
);
CREATE TABLE shipment_records (
  id TEXT PRIMARY KEY,
  shipment_number TEXT NOT NULL UNIQUE,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  quantity REAL NOT NULL CHECK (quantity > 0),
  is_complete INTEGER NOT NULL DEFAULT 0 CHECK (is_complete IN (0, 1)),
  carrier TEXT NOT NULL,
  tracking_number TEXT NOT NULL,
  box_count INTEGER NOT NULL CHECK (box_count > 0),
  shipped_at TEXT NOT NULL,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE TABLE shipment_attachments (
  id TEXT PRIMARY KEY,
  shipment_id TEXT NOT NULL REFERENCES shipment_records(id) ON DELETE CASCADE,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('shipment_photo', 'delivery_note')),
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  r2_key TEXT NOT NULL UNIQUE,
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE TABLE order_reminders (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  reminder_key TEXT NOT NULL,
  reminder_type TEXT NOT NULL CHECK (reminder_type IN ('seven_days', 'three_days', 'one_day', 'due_today', 'overdue')),
  message TEXT NOT NULL,
  target_date TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(order_id, reminder_key)
);
CREATE TABLE supplier_number_sequence (
  name TEXT PRIMARY KEY,
  prefix TEXT NOT NULL,
  current_value INTEGER NOT NULL CHECK (current_value >= 0)
);
CREATE TABLE supplier_products (
  id TEXT PRIMARY KEY,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  product_type TEXT NOT NULL CHECK (product_type IN ('配件类', '电气类', '安全防护类', '成品设备类', '定制加工类')),
  product_name TEXT NOT NULL,
  usual_specification TEXT NOT NULL DEFAULT '',
  unit TEXT NOT NULL DEFAULT '',
  default_unit_price REAL,
  production_cycle TEXT NOT NULL DEFAULT '',
  transport_method TEXT NOT NULL DEFAULT '',
  arrival_time TEXT NOT NULL DEFAULT '',
  settlement_method TEXT NOT NULL DEFAULT '',
  special_invoice_tax TEXT NOT NULL DEFAULT '',
  ordinary_invoice_tax TEXT NOT NULL DEFAULT '',
  order_required_materials TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL, product_category TEXT NOT NULL DEFAULT '',
  UNIQUE (supplier_id, product_name, usual_specification)
);
CREATE TABLE order_delivery_history (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  kind TEXT NOT NULL CHECK(kind IN ('baseline', 'initial', 'estimate', 'required')),
  previous_date TEXT,
  new_date TEXT NOT NULL,
  reason TEXT NOT NULL,
  actor_id TEXT REFERENCES users(id),
  actor_name TEXT NOT NULL,
  changed_at TEXT
);
CREATE TABLE supplier_commercial_terms (
  supplier_id TEXT PRIMARY KEY REFERENCES suppliers(id),
  terms_json TEXT NOT NULL CHECK(json_valid(terms_json)),
  revision INTEGER NOT NULL DEFAULT 1,
  updated_by TEXT NOT NULL REFERENCES users(id),
  updated_at TEXT NOT NULL
);
CREATE TABLE commercial_history (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  previous_json TEXT,
  actual_json TEXT NOT NULL CHECK(json_valid(actual_json)),
  status TEXT NOT NULL,
  reason TEXT NOT NULL,
  actor_id TEXT NOT NULL REFERENCES users(id),
  actor_name TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE order_settlements (
  order_id TEXT PRIMARY KEY REFERENCES purchase_orders(id),
  currency TEXT NOT NULL DEFAULT 'CNY' CHECK(currency = 'CNY'),
  net_cents INTEGER CHECK(net_cents >= 0),
  tax_cents INTEGER CHECK(tax_cents >= 0),
  payable_cents INTEGER CHECK(payable_cents >= 0), finance_confirmed INTEGER NOT NULL DEFAULT 0 CHECK(finance_confirmed IN (0, 1)), invoice_required INTEGER CHECK(invoice_required IN (0, 1)), revision INTEGER NOT NULL DEFAULT 0, finance_change_id TEXT,
  CHECK((net_cents IS NULL AND tax_cents IS NULL AND payable_cents IS NULL) OR payable_cents = net_cents + tax_cents)
);
CREATE TABLE financial_entries (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  kind TEXT NOT NULL CHECK(kind IN ('payment', 'invoice', 'cost')),
  amount_cents INTEGER NOT NULL CHECK(amount_cents != 0),
  record_date TEXT NOT NULL,
  reference TEXT NOT NULL,
  note TEXT NOT NULL,
  reversal_of TEXT UNIQUE REFERENCES financial_entries(id),
  actor_id TEXT NOT NULL REFERENCES users(id),
  actor_name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  CHECK((reversal_of IS NULL AND amount_cents > 0) OR (reversal_of IS NOT NULL AND amount_cents < 0))
);
CREATE TABLE shipment_items (
  shipment_id TEXT NOT NULL REFERENCES shipment_records(id),
  item_id TEXT NOT NULL REFERENCES order_items(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0 AND quantity = CAST(quantity AS INTEGER)),
  PRIMARY KEY (shipment_id, item_id)
);
CREATE TABLE product_acceptances (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  item_id TEXT NOT NULL REFERENCES order_items(id),
  production_revision INTEGER NOT NULL,
  decision TEXT NOT NULL CHECK (decision IN ('approved','rejected')),
  reason TEXT NOT NULL,
  photo_ids TEXT NOT NULL,
  actor_id TEXT NOT NULL REFERENCES users(id),
  actor_name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(item_id, production_revision)
);
CREATE TABLE account_changes (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  actor_id TEXT NOT NULL REFERENCES users(id),
  old_name TEXT NOT NULL,
  new_name TEXT NOT NULL,
  old_email TEXT NOT NULL,
  new_email TEXT NOT NULL,
  password_reset INTEGER NOT NULL CHECK(password_reset IN (0, 1)),
  created_at TEXT NOT NULL
, old_role TEXT, new_role TEXT, old_supplier_operations INTEGER, new_supplier_operations INTEGER, old_finance_settlement INTEGER, new_finance_settlement INTEGER);
CREATE TABLE "warehouse_records" (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES purchase_orders(id),
 item_id TEXT NOT NULL REFERENCES order_items(id), action TEXT NOT NULL CHECK(action IN ('received','stocked')),
 quantity INTEGER NOT NULL CHECK(typeof(quantity)='integer' AND quantity>=1),
 actor_id TEXT NOT NULL REFERENCES users(id), actor_name TEXT NOT NULL, created_at TEXT NOT NULL
, record_date TEXT
CHECK(record_date IS NULL OR (length(record_date)=10 AND record_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]')), receipt_id TEXT REFERENCES warehouse_receipts(id), warehouse_name TEXT, storage_location TEXT);
CREATE TABLE item_corrections (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES purchase_orders(id), item_id TEXT NOT NULL REFERENCES order_items(id),
 action TEXT NOT NULL CHECK(action IN ('acceptance','received','stocked')),
 quantity INTEGER NOT NULL CHECK(typeof(quantity)='integer' AND quantity>=1), reason TEXT NOT NULL CHECK(length(trim(reason))>0),
 expected_revision INTEGER NOT NULL, expected_received INTEGER NOT NULL, expected_stocked INTEGER NOT NULL,
 actor_id TEXT NOT NULL REFERENCES users(id), actor_name TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE staff_permissions (
  user_id TEXT PRIMARY KEY REFERENCES users(id),
  supplier_operations INTEGER NOT NULL DEFAULT 0 CHECK(supplier_operations IN (0,1))
, finance_settlement INTEGER NOT NULL DEFAULT 0 CHECK(finance_settlement IN (0,1)));
CREATE TABLE "staff_roles" (
  user_id TEXT PRIMARY KEY REFERENCES users(id),
  role TEXT NOT NULL CHECK(role IN ('purchaser','finance','boss','admin','management','engineering','warehouse','office'))
);
CREATE TABLE shipment_quantity_corrections (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  shipment_id TEXT NOT NULL REFERENCES shipment_records(id),
  item_id TEXT NOT NULL REFERENCES order_items(id),
  previous_quantity INTEGER NOT NULL CHECK(previous_quantity >= 0),
  corrected_quantity INTEGER NOT NULL CHECK(corrected_quantity >= 0),
  delta_quantity INTEGER NOT NULL CHECK(delta_quantity != 0),
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pending','applied','rejected')),
  requested_by TEXT NOT NULL REFERENCES users(id),
  requested_by_name TEXT NOT NULL,
  requested_at TEXT NOT NULL,
  decided_by TEXT REFERENCES users(id),
  decided_by_name TEXT,
  decided_at TEXT,
  decision_note TEXT
, requires_warehouse INTEGER NOT NULL DEFAULT 1 CHECK(requires_warehouse IN (0,1)));
CREATE TABLE warehouse_receipts (
  id TEXT PRIMARY KEY REFERENCES warehouse_records(id),
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  item_id TEXT NOT NULL REFERENCES order_items(id),
  received_quantity INTEGER NOT NULL CHECK(typeof(received_quantity)='integer' AND received_quantity>=1),
  received_date TEXT NOT NULL,
  received_by TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_inspection' CHECK(status IN ('pending_inspection','passed','exception','stocked')),
  exception_type TEXT,
  exception_quantity INTEGER,
  exception_notes TEXT NOT NULL DEFAULT '',
  inspected_at TEXT,
  inspected_by TEXT,
  stocked_quantity INTEGER NOT NULL DEFAULT 0 CHECK(typeof(stocked_quantity)='integer' AND stocked_quantity>=0),
  warehouse_name TEXT NOT NULL DEFAULT '',
  storage_location TEXT NOT NULL DEFAULT '',
  stocked_at TEXT,
  stocked_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL, cancelled_quantity INTEGER NOT NULL DEFAULT 0 CHECK(cancelled_quantity>=0 AND cancelled_quantity<=received_quantity), revision INTEGER NOT NULL DEFAULT 0, request_hash TEXT,
  CHECK(exception_type IS NULL OR exception_type IN ('shortage','overage','wrong_item','damaged','specification','other')),
  CHECK(exception_quantity IS NULL OR (typeof(exception_quantity)='integer' AND exception_quantity>=1 AND exception_quantity<=received_quantity)),
  CHECK(stocked_quantity<=received_quantity)
);
CREATE TABLE warehouse_receipt_attachments (
  id TEXT PRIMARY KEY,
  receipt_id TEXT NOT NULL REFERENCES warehouse_receipts(id),
  order_id TEXT NOT NULL REFERENCES purchase_orders(id),
  item_id TEXT NOT NULL REFERENCES order_items(id),
  kind TEXT NOT NULL CHECK(kind IN ('arrival_photo','delivery_note','exception_photo')),
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  r2_key TEXT NOT NULL UNIQUE,
  uploaded_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE TABLE warehouse_receipt_actions (
 id TEXT PRIMARY KEY, receipt_id TEXT NOT NULL REFERENCES warehouse_receipts(id),
 action TEXT NOT NULL CHECK(action IN ('passed','exception','resolve')),
 exception_type TEXT, exception_quantity INTEGER, note TEXT NOT NULL DEFAULT '',
 expected_revision INTEGER NOT NULL, request_hash TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES users(id), actor_name TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE warehouse_correction_allocations (
 correction_id TEXT NOT NULL REFERENCES item_corrections(id), receipt_id TEXT NOT NULL REFERENCES warehouse_receipts(id),
 quantity INTEGER NOT NULL CHECK(quantity>0), PRIMARY KEY(correction_id,receipt_id)
);
CREATE TABLE warehouse_batch_reconciliations (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES purchase_orders(id), item_id TEXT NOT NULL REFERENCES order_items(id),
 expected_received INTEGER NOT NULL, expected_stocked INTEGER NOT NULL,
 previous_json TEXT NOT NULL, allocations_json TEXT NOT NULL, reason TEXT NOT NULL CHECK(length(trim(reason))>0),
 actor_id TEXT NOT NULL REFERENCES users(id), actor_name TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE customers(id TEXT PRIMARY KEY,code TEXT NOT NULL UNIQUE,name TEXT NOT NULL,contact TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '',email TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL, created_by TEXT REFERENCES employees(id));
CREATE TABLE projects(id TEXT PRIMARY KEY,code TEXT NOT NULL UNIQUE,name TEXT NOT NULL,customer_id TEXT NOT NULL REFERENCES customers(id),location TEXT NOT NULL DEFAULT '',owner TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'active',version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL, member_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE employees(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE COLLATE NOCASE,name TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','ceo','sales','purchasing','engineering','warehouse','installation','aftersales','finance','supplier')),supplier_id TEXT REFERENCES suppliers(id),status TEXT NOT NULL DEFAULT 'active',password_hash TEXT NOT NULL,salt TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE employee_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES employees(id),expires REAL NOT NULL,csrf TEXT NOT NULL,project_id TEXT REFERENCES projects(id),quote_kind TEXT NOT NULL DEFAULT 'original',parent_order_id TEXT);
CREATE TABLE login_attempts(email TEXT PRIMARY KEY,count INTEGER NOT NULL,expires REAL NOT NULL);
CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE audit_events(id TEXT PRIMARY KEY,entity TEXT NOT NULL,entity_id TEXT NOT NULL,action TEXT NOT NULL,actor_id TEXT,actor_name TEXT NOT NULL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE products(id TEXT PRIMARY KEY,sku TEXT NOT NULL,name TEXT NOT NULL,english_name TEXT NOT NULL DEFAULT '',specification TEXT NOT NULL DEFAULT '',unit TEXT NOT NULL DEFAULT '',image_key TEXT NOT NULL DEFAULT '',source TEXT NOT NULL DEFAULT 'quote',created_at TEXT NOT NULL);
CREATE TABLE order_baselines(id TEXT PRIMARY KEY,number TEXT NOT NULL UNIQUE,project_id TEXT NOT NULL REFERENCES projects(id),quote_id TEXT NOT NULL UNIQUE REFERENCES quotation_history(id),kind TEXT NOT NULL CHECK(kind IN ('original','addition')),parent_order_id TEXT REFERENCES order_baselines(id),currency TEXT NOT NULL CHECK(currency IN ('CNY','USD')),agreed_minor INTEGER NOT NULL CHECK(agreed_minor>0),raw_snapshot TEXT NOT NULL,deposit_required_minor INTEGER CHECK(deposit_required_minor>=0),created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE baseline_lines(id TEXT PRIMARY KEY,baseline_id TEXT NOT NULL REFERENCES order_baselines(id),product_id TEXT REFERENCES products(id),source_product_id TEXT NOT NULL,name TEXT NOT NULL,sku TEXT NOT NULL,model TEXT NOT NULL DEFAULT '',specification TEXT NOT NULL,unit TEXT NOT NULL,quantity REAL NOT NULL CHECK(quantity>0),line_order INTEGER NOT NULL,raw_snapshot TEXT NOT NULL,UNIQUE(baseline_id,source_product_id));
CREATE TABLE deposit_confirmations(id TEXT PRIMARY KEY,baseline_id TEXT NOT NULL REFERENCES order_baselines(id),amount_minor INTEGER NOT NULL CHECK(amount_minor>0),currency TEXT NOT NULL,reference TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,UNIQUE(baseline_id,reference));
CREATE TABLE release_requests(id TEXT PRIMARY KEY,baseline_id TEXT NOT NULL REFERENCES order_baselines(id),reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),requested_by TEXT NOT NULL REFERENCES employees(id),decided_by TEXT REFERENCES employees(id),decision_note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,decided_at TEXT);
CREATE TABLE order_changes(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),baseline_line_id TEXT NOT NULL REFERENCES baseline_lines(id),new_product_id TEXT REFERENCES products(id),new_quantity REAL NOT NULL CHECK(new_quantity>=0),new_model TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL,customer_evidence TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',version INTEGER NOT NULL DEFAULT 1,confirmed_by TEXT REFERENCES employees(id),confirmed_at TEXT,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE procurement_context(order_id TEXT PRIMARY KEY REFERENCES purchase_orders(id),project_id TEXT REFERENCES projects(id),baseline_id TEXT REFERENCES order_baselines(id),purpose TEXT NOT NULL CHECK(purpose IN ('project','stock','service')),service_ticket_id TEXT,created_at TEXT NOT NULL);
CREATE TABLE procurement_allocations(id TEXT PRIMARY KEY,baseline_line_id TEXT NOT NULL REFERENCES baseline_lines(id),order_item_id TEXT NOT NULL UNIQUE REFERENCES order_items(id),quantity REAL NOT NULL CHECK(quantity>0));
CREATE TABLE service_tickets(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),delivery_line_id TEXT,payload TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE service_parts(product_id TEXT PRIMARY KEY REFERENCES products(id),min_stock REAL NOT NULL DEFAULT 0,notes TEXT NOT NULL DEFAULT '');
CREATE TABLE service_events(id TEXT PRIMARY KEY,ticket_id TEXT NOT NULL REFERENCES service_tickets(id),actor_id TEXT REFERENCES employees(id),payload TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE service_requests(id TEXT PRIMARY KEY,ticket_id TEXT NOT NULL REFERENCES service_tickets(id),product_id TEXT REFERENCES products(id),quantity REAL NOT NULL CHECK(quantity>0),note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,order_id TEXT REFERENCES purchase_orders(id));
CREATE TABLE stock_reservations(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),quantity REAL NOT NULL CHECK(quantity>0),purpose TEXT NOT NULL CHECK(purpose IN ('delivery','service')),baseline_line_id TEXT REFERENCES baseline_lines(id),ticket_id TEXT REFERENCES service_tickets(id),status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','issued','cancelled')),actor_id TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE stock_movements(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),quantity REAL NOT NULL CHECK(quantity!=0),kind TEXT NOT NULL,order_item_id TEXT REFERENCES order_items(id),ticket_id TEXT REFERENCES service_tickets(id),reference_id TEXT,note TEXT NOT NULL DEFAULT '',actor_id TEXT,created_at TEXT NOT NULL, location_id TEXT NOT NULL DEFAULT 'unassigned' REFERENCES warehouse_locations(id));
CREATE TABLE deliveries(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),number TEXT NOT NULL UNIQUE,carrier TEXT NOT NULL,tracking_number TEXT NOT NULL,delivered_at TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE delivery_lines(id TEXT PRIMARY KEY,delivery_id TEXT NOT NULL REFERENCES deliveries(id),baseline_line_id TEXT NOT NULL REFERENCES baseline_lines(id),product_id TEXT NOT NULL REFERENCES products(id),quantity REAL NOT NULL CHECK(quantity>0),name_snapshot TEXT NOT NULL,model_snapshot TEXT NOT NULL,stock_movement_id TEXT NOT NULL UNIQUE REFERENCES stock_movements(id));
CREATE TABLE customer_financial_entries(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),baseline_id TEXT NOT NULL REFERENCES order_baselines(id),kind TEXT NOT NULL CHECK(kind IN ('receipt','credit','surcharge')),amount_minor INTEGER NOT NULL CHECK(amount_minor!=0),currency TEXT NOT NULL CHECK(currency IN ('CNY','USD')),reference TEXT NOT NULL,note TEXT NOT NULL,change_id TEXT REFERENCES order_changes(id),reversal_of TEXT UNIQUE REFERENCES customer_financial_entries(id),actor_id TEXT NOT NULL REFERENCES employees(id),record_date TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE shared_attachments(id TEXT PRIMARY KEY,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,file_name TEXT NOT NULL,content_type TEXT NOT NULL,size INTEGER NOT NULL,object_key TEXT NOT NULL UNIQUE,actor_id TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE legacy_records(id TEXT PRIMARY KEY,source_system TEXT NOT NULL,source_environment TEXT NOT NULL,entity_type TEXT NOT NULL,legacy_id TEXT NOT NULL,raw_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',target_id TEXT,imported_at TEXT NOT NULL,UNIQUE(source_system,source_environment,entity_type,legacy_id));
CREATE TABLE purchase_item_changes(id TEXT PRIMARY KEY,change_id TEXT NOT NULL REFERENCES order_changes(id),item_id TEXT NOT NULL REFERENCES order_items(id),old_product TEXT,old_model TEXT,old_quantity REAL,old_price REAL,new_product TEXT NOT NULL REFERENCES products(id),new_model TEXT NOT NULL,new_quantity REAL NOT NULL,new_price REAL NOT NULL,new_name TEXT NOT NULL,new_unit TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES employees(id),applied INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
CREATE TABLE project_members (
  project_id TEXT NOT NULL REFERENCES projects(id),
  employee_id TEXT NOT NULL REFERENCES employees(id),
  assignment_role TEXT NOT NULL CHECK(assignment_role IN ('owner','member')),
  assigned_by TEXT NOT NULL REFERENCES employees(id),
  assigned_at TEXT NOT NULL,
  PRIMARY KEY(project_id,employee_id)
);
CREATE TABLE engineering_orders(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),baseline_id TEXT NOT NULL REFERENCES order_baselines(id),number TEXT NOT NULL UNIQUE,revision INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'draft',required_date TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',lines_json TEXT NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),released_by TEXT REFERENCES employees(id),released_at TEXT,version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,UNIQUE(baseline_id,revision));
CREATE TABLE engineering_purchase_links(order_id TEXT PRIMARY KEY REFERENCES purchase_orders(id),engineering_id TEXT NOT NULL REFERENCES engineering_orders(id));
CREATE TABLE work_tasks(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),kind TEXT NOT NULL CHECK(kind IN ('task','installation','issue')),title TEXT NOT NULL,owner_id TEXT NOT NULL REFERENCES employees(id),due_date TEXT NOT NULL,status TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',location TEXT NOT NULL DEFAULT '',blocking INTEGER NOT NULL DEFAULT 0,resolution TEXT NOT NULL DEFAULT '',acceptance TEXT NOT NULL DEFAULT '',created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE warehouse_locations(id TEXT PRIMARY KEY,code TEXT NOT NULL UNIQUE,warehouse TEXT NOT NULL,name TEXT NOT NULL,category TEXT NOT NULL DEFAULT 'purchase',usable INTEGER NOT NULL DEFAULT 1 CHECK(usable IN (0,1)));
CREATE TABLE warehouse_operations(id TEXT PRIMARY KEY,number TEXT NOT NULL UNIQUE,kind TEXT NOT NULL,product_id TEXT NOT NULL REFERENCES products(id),source_id TEXT REFERENCES warehouse_locations(id),destination_id TEXT REFERENCES warehouse_locations(id),quantity REAL NOT NULL,reference TEXT NOT NULL,note TEXT NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE stock_counts(id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),location_id TEXT NOT NULL REFERENCES warehouse_locations(id),expected REAL NOT NULL,counted REAL NOT NULL,fingerprint TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',created_by TEXT NOT NULL REFERENCES employees(id),posted_by TEXT REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
CREATE TABLE equipment_assets(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),delivery_line_id TEXT NOT NULL REFERENCES delivery_lines(id),serial TEXT NOT NULL UNIQUE,name TEXT NOT NULL,location TEXT NOT NULL,warranty_start TEXT NOT NULL,warranty_end TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE return_cases(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),delivery_line_id TEXT NOT NULL REFERENCES delivery_lines(id),kind TEXT NOT NULL CHECK(kind IN ('return','exchange','repair')),quantity REAL NOT NULL CHECK(quantity>0),reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'requested',replacement_product_id TEXT REFERENCES products(id),location_id TEXT REFERENCES warehouse_locations(id),resolution TEXT NOT NULL DEFAULT '',responsibility TEXT NOT NULL DEFAULT '',sales_by TEXT REFERENCES employees(id),received_by TEXT REFERENCES employees(id),received_at TEXT,created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE crm_leads(id TEXT PRIMARY KEY,name TEXT NOT NULL,company TEXT NOT NULL,contact TEXT NOT NULL,phone TEXT NOT NULL DEFAULT '',source TEXT NOT NULL,owner_id TEXT NOT NULL REFERENCES employees(id),status TEXT NOT NULL DEFAULT 'new',next_date TEXT NOT NULL,next_action TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',customer_id TEXT REFERENCES customers(id),created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL, region TEXT NOT NULL DEFAULT '', activity TEXT NOT NULL DEFAULT '', validity_reason TEXT NOT NULL DEFAULT '');
CREATE TABLE crm_opportunities(id TEXT PRIMARY KEY,lead_id TEXT NOT NULL REFERENCES crm_leads(id),customer_id TEXT NOT NULL REFERENCES customers(id),project_id TEXT REFERENCES projects(id),name TEXT NOT NULL,owner_id TEXT NOT NULL REFERENCES employees(id),stage TEXT NOT NULL DEFAULT 'discovery',expected_minor INTEGER, currency TEXT NOT NULL CHECK(currency IN ('CNY','USD')),expected_date TEXT NOT NULL,next_action TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE project_budgets(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),currency TEXT NOT NULL CHECK(currency IN ('CNY','USD')),amount_minor INTEGER NOT NULL CHECK(amount_minor>=0),note TEXT NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(project_id,currency));
CREATE TABLE project_expenses(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),category TEXT NOT NULL,amount_minor INTEGER NOT NULL CHECK(amount_minor>0),currency TEXT NOT NULL CHECK(currency IN ('CNY','USD')),record_date TEXT NOT NULL,reference TEXT NOT NULL UNIQUE,note TEXT NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),version INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE operation_files(id TEXT PRIMARY KEY,entity TEXT NOT NULL,entity_id TEXT NOT NULL,file_name TEXT NOT NULL,mime TEXT NOT NULL,content BLOB NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE center_members(employee_id TEXT NOT NULL REFERENCES employees(id),center TEXT NOT NULL CHECK(center IN ('marketing','design')),PRIMARY KEY(employee_id,center));
CREATE TABLE marketing_spends(id TEXT PRIMARY KEY,number TEXT NOT NULL UNIQUE,record_date TEXT NOT NULL,channel TEXT NOT NULL,expense_type TEXT NOT NULL,amount_minor INTEGER NOT NULL CHECK(amount_minor>=0),currency TEXT NOT NULL,activity TEXT NOT NULL DEFAULT '',region TEXT NOT NULL DEFAULT '',owner_id TEXT NOT NULL REFERENCES employees(id),project_id TEXT REFERENCES projects(id),reference TEXT NOT NULL DEFAULT '',note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','void')),version INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE design_tasks(id TEXT PRIMARY KEY,number TEXT NOT NULL UNIQUE,project_id TEXT NOT NULL REFERENCES projects(id),title TEXT NOT NULL,task_type TEXT NOT NULL,brief TEXT NOT NULL,requested_date TEXT NOT NULL,due_date TEXT,original_due_date TEXT,owner_id TEXT REFERENCES employees(id),team TEXT NOT NULL DEFAULT '',priority TEXT NOT NULL DEFAULT 'normal',status TEXT NOT NULL DEFAULT 'queued',version_label TEXT NOT NULL DEFAULT '',revision_count INTEGER NOT NULL DEFAULT 0,result_reference TEXT NOT NULL DEFAULT '',confirmation TEXT NOT NULL DEFAULT '',change_reason TEXT NOT NULL DEFAULT '',handoff_note TEXT NOT NULL DEFAULT '',completed_at TEXT,accepted_at TEXT,version INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE center_events(id TEXT PRIMARY KEY,entity TEXT NOT NULL,entity_id TEXT NOT NULL,action TEXT NOT NULL,before_json TEXT NOT NULL,after_json TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',actor_id TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE crm_followups(id TEXT PRIMARY KEY,entity TEXT NOT NULL CHECK(entity IN ('leads','opportunities')),entity_id TEXT NOT NULL,contact_date TEXT NOT NULL,result TEXT NOT NULL,next_action TEXT NOT NULL,next_date TEXT NOT NULL,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL);
CREATE TABLE center_targets(id TEXT PRIMARY KEY,center TEXT NOT NULL,month TEXT NOT NULL,metric TEXT NOT NULL,currency TEXT NOT NULL,value INTEGER NOT NULL CHECK(value>=0),version INTEGER NOT NULL DEFAULT 1,created_by TEXT NOT NULL REFERENCES employees(id),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(center,month,metric,currency));
CREATE TABLE connected_sales (
 source_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL UNIQUE REFERENCES customers(id),
 project_id TEXT REFERENCES projects(id), payload TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
 synced_at TEXT NOT NULL
);
CREATE TABLE connected_quotes (
 id TEXT PRIMARY KEY, project_id TEXT REFERENCES projects(id), payload TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1, synced_at TEXT NOT NULL
);
CREATE TABLE connection_runs (
 source TEXT PRIMARY KEY, last_success TEXT, last_attempt TEXT NOT NULL, error TEXT NOT NULL DEFAULT '', count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX `password_reset_tokens_email_idx` ON `password_reset_tokens` (`email`);
CREATE INDEX `quotation_history_generated_at_idx` ON `quotation_history` (`generated_at`);
CREATE INDEX `product_classifications_product_id_idx`
	ON `product_classifications` (`product_id`);
CREATE UNIQUE INDEX `product_classifications_path_idx`
	ON `product_classifications` (`product_id`, `level_1`, `level_2`, `level_3`);
CREATE INDEX `quotation_history_created_by_generated_at_idx`
  ON `quotation_history` (`created_by`, `generated_at`);
CREATE INDEX `quotation_history_archived_at_idx` ON `quotation_history` (`archived_at`);
CREATE INDEX `quotation_history_lineage_id_idx` ON `quotation_history` (`lineage_id`);
CREATE INDEX `quotation_history_project_status_idx` ON `quotation_history` (`project_status`);
CREATE INDEX `toy_matching_drafts_created_by_updated_at_idx`
  ON `toy_matching_drafts` (`created_by`, `updated_at`);
CREATE INDEX `quotation_history_loss_reason_idx` ON `quotation_history` (`loss_reason`);
CREATE INDEX sessions_user_id_idx ON sessions(user_id);
CREATE INDEX purchase_orders_supplier_id_idx ON purchase_orders(supplier_id);
CREATE INDEX purchase_orders_status_idx ON purchase_orders(status);
CREATE INDEX order_items_order_id_idx ON order_items(order_id);
CREATE INDEX attachments_order_id_idx ON attachments(order_id);
CREATE INDEX order_events_order_id_idx ON order_events(order_id);
CREATE INDEX auth_attempts_updated_at_idx ON auth_attempts(updated_at);
CREATE INDEX shipment_records_order_id_idx ON shipment_records(order_id);
CREATE INDEX shipment_records_shipped_at_idx ON shipment_records(shipped_at);
CREATE INDEX shipment_attachments_shipment_id_idx ON shipment_attachments(shipment_id);
CREATE INDEX shipment_attachments_order_id_idx ON shipment_attachments(order_id);
CREATE INDEX order_reminders_order_id_idx ON order_reminders(order_id);
CREATE INDEX order_reminders_created_at_idx ON order_reminders(created_at);
CREATE INDEX supplier_products_supplier_id_idx ON supplier_products(supplier_id);
CREATE UNIQUE INDEX supplier_code_permanent ON suppliers(lower(trim(code)));
CREATE UNIQUE INDEX po_number_permanent ON purchase_orders(lower(trim(po_number)));
CREATE INDEX delivery_history_order ON order_delivery_history(order_id, changed_at);
CREATE INDEX commercial_history_order ON commercial_history(order_id);
CREATE INDEX finance_order ON financial_entries(order_id);
CREATE INDEX finance_reference ON financial_entries(order_id, kind, reference);
CREATE INDEX warehouse_records_item ON warehouse_records(item_id,created_at);
CREATE INDEX shipment_quantity_corrections_shipment_idx ON shipment_quantity_corrections(shipment_id, item_id, requested_at);
CREATE INDEX shipment_quantity_corrections_pending_idx ON shipment_quantity_corrections(status, requested_at);
CREATE INDEX warehouse_receipts_status_idx ON warehouse_receipts(status,updated_at);
CREATE INDEX warehouse_receipts_item_idx ON warehouse_receipts(item_id,created_at);
CREATE INDEX warehouse_receipt_attachments_receipt_idx ON warehouse_receipt_attachments(receipt_id,created_at);
CREATE INDEX products_sku_idx ON products(sku);
CREATE UNIQUE INDEX one_pending_release ON release_requests(baseline_id) WHERE status='pending';
CREATE INDEX stock_product_idx ON stock_movements(product_id);
CREATE UNIQUE INDEX customer_finance_reference ON customer_financial_entries(baseline_id,kind,reference) WHERE reversal_of IS NULL;
CREATE UNIQUE INDEX project_one_owner ON project_members(project_id) WHERE assignment_role='owner';
CREATE INDEX employee_projects ON project_members(employee_id,project_id);
CREATE INDEX work_tasks_project ON work_tasks(project_id,kind,status);
CREATE INDEX work_tasks_owner ON work_tasks(owner_id,due_date);
CREATE INDEX location_stock ON stock_movements(location_id,product_id);
CREATE INDEX operation_files_entity ON operation_files(entity,entity_id);
CREATE INDEX design_tasks_project ON design_tasks(project_id,status);
CREATE TRIGGER supplier_identity_fixed BEFORE UPDATE OF id, code ON suppliers
WHEN NEW.id IS NOT OLD.id OR NEW.code IS NOT OLD.code
BEGIN SELECT RAISE(ABORT, 'Supplier identity is immutable'); END;
CREATE TRIGGER po_keep_history BEFORE DELETE ON purchase_orders
BEGIN SELECT RAISE(ABORT, 'Archive orders instead of deleting'); END;
CREATE TRIGGER archived_po_read_only BEFORE UPDATE ON purchase_orders
WHEN OLD.archived_at IS NOT NULL
BEGIN SELECT RAISE(ABORT, 'Archived orders are read only'); END;
CREATE TRIGGER original_promise_fixed BEFORE UPDATE OF promised_ship_date ON purchase_orders
WHEN OLD.promised_ship_date IS NOT NULL AND NEW.promised_ship_date IS NOT OLD.promised_ship_date
BEGIN SELECT RAISE(ABORT, 'Original promised date is immutable'); END;
CREATE TRIGGER delivery_audit_required BEFORE UPDATE OF promised_ship_date, estimated_ship_date, required_ship_date ON purchase_orders
WHEN (NEW.promised_ship_date IS NOT OLD.promised_ship_date OR NEW.estimated_ship_date IS NOT OLD.estimated_ship_date OR NEW.required_ship_date IS NOT OLD.required_ship_date)
 AND (NEW.delivery_actor_id IS NULL OR trim(NEW.delivery_actor_name) = '' OR trim(NEW.delivery_change_reason) = '' OR NEW.delivery_revision != OLD.delivery_revision + 1)
BEGIN SELECT RAISE(ABORT, 'Delivery changes require revision, actor and reason'); END;
CREATE TRIGGER initial_promise_history AFTER UPDATE OF promised_ship_date ON purchase_orders
WHEN OLD.promised_ship_date IS NULL AND NEW.promised_ship_date IS NOT NULL
BEGIN
  INSERT INTO order_delivery_history VALUES (lower(hex(randomblob(16))), NEW.id, 'initial', NULL, NEW.promised_ship_date, NEW.delivery_change_reason, NEW.delivery_actor_id, NEW.delivery_actor_name, NEW.updated_at);
END;
CREATE TRIGGER estimate_history AFTER UPDATE OF estimated_ship_date ON purchase_orders
WHEN OLD.promised_ship_date IS NOT NULL AND NEW.estimated_ship_date IS NOT OLD.estimated_ship_date
BEGIN
  INSERT INTO order_delivery_history VALUES (lower(hex(randomblob(16))), NEW.id, 'estimate', OLD.estimated_ship_date, NEW.estimated_ship_date, NEW.delivery_change_reason, NEW.delivery_actor_id, NEW.delivery_actor_name, NEW.updated_at);
END;
CREATE TRIGGER required_date_history AFTER UPDATE OF required_ship_date ON purchase_orders
WHEN NEW.required_ship_date IS NOT OLD.required_ship_date
BEGIN
  INSERT INTO order_delivery_history VALUES (lower(hex(randomblob(16))), NEW.id, 'required', OLD.required_ship_date, NEW.required_ship_date, NEW.delivery_change_reason, NEW.delivery_actor_id, NEW.delivery_actor_name, NEW.updated_at);
END;
CREATE TRIGGER delivery_history_no_update BEFORE UPDATE ON order_delivery_history
BEGIN SELECT RAISE(ABORT, 'Delivery history is append only'); END;
CREATE TRIGGER delivery_history_no_delete BEFORE DELETE ON order_delivery_history
BEGIN SELECT RAISE(ABORT, 'Delivery history is append only'); END;
CREATE TRIGGER events_no_update BEFORE UPDATE ON order_events
BEGIN SELECT RAISE(ABORT, 'Order events are append only'); END;
CREATE TRIGGER events_no_delete BEFORE DELETE ON order_events
BEGIN SELECT RAISE(ABORT, 'Order events are append only'); END;
CREATE TRIGGER archived_attachments_read_only BEFORE INSERT ON attachments
WHEN EXISTS (SELECT 1 FROM purchase_orders WHERE id = NEW.order_id AND archived_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT, 'Cannot add files to archived orders'); END;
CREATE TRIGGER archived_shipments_read_only BEFORE INSERT ON shipment_records
WHEN EXISTS (SELECT 1 FROM purchase_orders WHERE id = NEW.order_id AND archived_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT, 'Cannot ship archived orders'); END;
CREATE TRIGGER finance_duplicate_reference BEFORE INSERT ON financial_entries
WHEN NEW.reversal_of IS NULL AND EXISTS (
  SELECT 1 FROM financial_entries e WHERE e.order_id = NEW.order_id AND e.kind = NEW.kind
    AND lower(trim(e.reference)) = lower(trim(NEW.reference)) AND e.reversal_of IS NULL
    AND NOT EXISTS(SELECT 1 FROM financial_entries r WHERE r.reversal_of = e.id)
)
BEGIN SELECT RAISE(ABORT, 'Duplicate active financial reference'); END;
CREATE TRIGGER finance_no_update BEFORE UPDATE ON financial_entries
BEGIN SELECT RAISE(ABORT, 'Financial records are append only'); END;
CREATE TRIGGER finance_no_delete BEFORE DELETE ON financial_entries
BEGIN SELECT RAISE(ABORT, 'Financial records are append only'); END;
CREATE TRIGGER commercial_history_no_update BEFORE UPDATE ON commercial_history
BEGIN SELECT RAISE(ABORT, 'Commercial history is append only'); END;
CREATE TRIGGER commercial_history_no_delete BEFORE DELETE ON commercial_history
BEGIN SELECT RAISE(ABORT, 'Commercial history is append only'); END;
CREATE TRIGGER finance_reversal_valid BEFORE INSERT ON financial_entries
WHEN NEW.reversal_of IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM financial_entries e WHERE e.id = NEW.reversal_of AND e.order_id = NEW.order_id
    AND e.kind = NEW.kind AND e.amount_cents = -NEW.amount_cents AND e.reversal_of IS NULL
)
BEGIN SELECT RAISE(ABORT, 'Reversal must exactly offset its original record'); END;
CREATE TRIGGER settled_amount_locked BEFORE UPDATE ON order_settlements
WHEN (NEW.net_cents IS NOT OLD.net_cents OR NEW.tax_cents IS NOT OLD.tax_cents OR NEW.payable_cents IS NOT OLD.payable_cents)
 AND EXISTS(SELECT 1 FROM financial_entries WHERE order_id = OLD.order_id)
BEGIN SELECT RAISE(ABORT, 'Orders with financial records cannot change their price basis'); END;
CREATE TRIGGER shipment_item_validate BEFORE INSERT ON shipment_items
WHEN NOT EXISTS (SELECT 1 FROM order_items i JOIN shipment_records s ON s.id = NEW.shipment_id WHERE i.id = NEW.item_id AND i.order_id = s.order_id AND i.shipped_quantity + NEW.quantity <= i.quantity)
BEGIN
  SELECT RAISE(ABORT, '产品发货数量或归属无效，请刷新订单');
END;
CREATE TRIGGER shipment_item_apply AFTER INSERT ON shipment_items BEGIN
  UPDATE order_items SET shipped_quantity = shipped_quantity + NEW.quantity,
    workflow_stage = IIF(shipped_quantity + NEW.quantity = quantity, 'shipment_complete', workflow_stage)
    WHERE id = NEW.item_id;
END;
CREATE TRIGGER shipment_item_no_update BEFORE UPDATE ON shipment_items BEGIN SELECT RAISE(ABORT, '发货明细不可覆盖'); END;
CREATE TRIGGER shipment_item_no_delete BEFORE DELETE ON shipment_items BEGIN SELECT RAISE(ABORT, '发货明细不可删除'); END;
CREATE TRIGGER shipped_product_lock BEFORE UPDATE OF completion_date, workflow_stage ON order_items
WHEN (OLD.shipped_quantity > 0 AND NEW.shipped_quantity = OLD.shipped_quantity OR EXISTS (SELECT 1 FROM purchase_orders WHERE id = OLD.order_id AND status IN ('shipped', 'received', 'completed')))
AND (NEW.completion_date IS NOT OLD.completion_date OR NEW.workflow_stage IS NOT OLD.workflow_stage)
BEGIN SELECT RAISE(ABORT, '已发货产品的生产信息已锁定'); END;
CREATE TRIGGER product_acceptance_apply AFTER INSERT ON product_acceptances BEGIN
  UPDATE order_items SET acceptance_status = NEW.decision WHERE id = NEW.item_id;
  UPDATE purchase_orders SET status = 'ready_to_ship', updated_at = NEW.created_at
    WHERE id = NEW.order_id AND status = 'in_production' AND NEW.decision = 'approved';
END;
CREATE TRIGGER product_acceptance_no_update BEFORE UPDATE ON product_acceptances
BEGIN SELECT RAISE(ABORT, '验收记录不可覆盖'); END;
CREATE TRIGGER product_acceptance_no_delete BEFORE DELETE ON product_acceptances
BEGIN SELECT RAISE(ABORT, '验收记录不可删除'); END;
CREATE TRIGGER product_photo_recheck AFTER INSERT ON attachments WHEN NEW.kind = 'production_photo' BEGIN
  UPDATE order_items SET acceptance_status = 'pending', production_revision = production_revision + 1 WHERE id = NEW.item_id;
END;
CREATE TRIGGER product_progress_recheck AFTER UPDATE OF workflow_stage, completion_date ON order_items
WHEN NEW.shipped_quantity = 0 AND (NEW.workflow_stage IS NOT OLD.workflow_stage OR NEW.completion_date IS NOT OLD.completion_date)
BEGIN
  UPDATE order_items SET acceptance_status = 'pending', production_revision = production_revision + 1 WHERE id = NEW.id;
END;
CREATE TRIGGER account_changes_no_update BEFORE UPDATE ON account_changes
BEGIN SELECT RAISE(ABORT, 'Account history is immutable'); END;
CREATE TRIGGER account_changes_no_delete BEFORE DELETE ON account_changes
BEGIN SELECT RAISE(ABORT, 'Account history is immutable'); END;
CREATE TRIGGER production_photo_item_guard BEFORE INSERT ON attachments
WHEN NEW.kind = 'production_photo' AND NOT EXISTS (
  SELECT 1 FROM order_items i JOIN purchase_orders p ON p.id=i.order_id
  WHERE i.id=NEW.item_id AND i.order_id=NEW.order_id AND i.shipped_quantity=0
    AND p.status IN ('pending_confirmation','in_production','ready_to_ship') AND p.archived_at IS NULL
)
BEGIN SELECT RAISE(ABORT, '生产实拍必须关联未发货产品'); END;
CREATE TRIGGER archived_items_read_only BEFORE UPDATE ON order_items
WHEN EXISTS (SELECT 1 FROM purchase_orders WHERE id=OLD.order_id AND archived_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'Archived order items are read only'); END;
CREATE TRIGGER warehouse_record_apply AFTER INSERT ON warehouse_records BEGIN
 UPDATE order_items SET received_quantity=received_quantity+NEW.quantity, received_at=NEW.created_at, received_by=NEW.actor_name WHERE id=NEW.item_id AND NEW.action='received';
 UPDATE order_items SET stocked_quantity=stocked_quantity+NEW.quantity, stocked_at=NEW.created_at, stocked_by=NEW.actor_name WHERE id=NEW.item_id AND NEW.action='stocked';
 UPDATE purchase_orders SET status='received',updated_at=NEW.created_at WHERE id=NEW.order_id AND status='shipped'
 AND NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=NEW.order_id AND received_quantity<quantity);
END;
CREATE TRIGGER warehouse_record_no_update BEFORE UPDATE ON warehouse_records BEGIN SELECT RAISE(ABORT,'仓库记录不可覆盖'); END;
CREATE TRIGGER warehouse_record_no_delete BEFORE DELETE ON warehouse_records BEGIN SELECT RAISE(ABORT,'仓库记录不可删除'); END;
CREATE TRIGGER freight_payment_history AFTER UPDATE OF freight_payment_status ON order_items
WHEN NEW.freight_payment_status != OLD.freight_payment_status BEGIN
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at)
 SELECT lower(hex(randomblob(16))),NEW.order_id,'freight_payment',NEW.product_name||' · 运费支付状态：'||
 CASE OLD.freight_payment_status WHEN 'paid' THEN '已支付' WHEN 'unpaid' THEN '未支付' ELSE '待填写' END ||' → '||
 CASE NEW.freight_payment_status WHEN 'paid' THEN '已支付' WHEN 'unpaid' THEN '未支付' ELSE '待填写' END ,
 NEW.freight_payment_by,name,NEW.freight_payment_at FROM users WHERE id=NEW.freight_payment_by;
END;
CREATE TRIGGER item_correction_guard BEFORE INSERT ON item_corrections
WHEN NOT EXISTS(SELECT 1 FROM order_items i JOIN purchase_orders p ON p.id=i.order_id
 WHERE i.id=NEW.item_id AND i.order_id=NEW.order_id AND p.archived_at IS NULL
 AND i.production_revision=NEW.expected_revision AND i.received_quantity=NEW.expected_received AND i.stocked_quantity=NEW.expected_stocked
 AND ((NEW.action='acceptance' AND i.acceptance_status IN ('approved','rejected') AND i.shipped_quantity=0 AND i.received_quantity=0 AND i.stocked_quantity=0)
 OR (NEW.action='received' AND NEW.quantity<=i.received_quantity-i.stocked_quantity)
 OR (NEW.action='stocked' AND NEW.quantity<=i.stocked_quantity)))
BEGIN SELECT RAISE(ABORT,'更正状态已变化或存在后续记录，请先撤销后续操作'); END;
CREATE TRIGGER item_correction_apply AFTER INSERT ON item_corrections BEGIN
 UPDATE order_items SET acceptance_status='pending',production_revision=production_revision+1 WHERE id=NEW.item_id AND NEW.action='acceptance';
 UPDATE order_items SET received_quantity=received_quantity-NEW.quantity,
 received_at= CASE WHEN received_quantity=NEW.quantity THEN NULL ELSE received_at END ,
 received_by= CASE WHEN received_quantity=NEW.quantity THEN NULL ELSE received_by END WHERE id=NEW.item_id AND NEW.action='received';
 UPDATE order_items SET stocked_quantity=stocked_quantity-NEW.quantity,
 stocked_at= CASE WHEN stocked_quantity=NEW.quantity THEN NULL ELSE stocked_at END ,
 stocked_by= CASE WHEN stocked_quantity=NEW.quantity THEN NULL ELSE stocked_by END WHERE id=NEW.item_id AND NEW.action='stocked';
 UPDATE purchase_orders SET status='shipped',updated_at=NEW.created_at WHERE id=NEW.order_id AND status IN ('received','completed') AND NEW.action='received';
 UPDATE purchase_orders SET status='received',updated_at=NEW.created_at WHERE id=NEW.order_id AND status='completed' AND NEW.action='stocked';
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at)
 SELECT NEW.id,NEW.order_id,'item_correction',product_name||' · '|| CASE NEW.action WHEN 'acceptance' THEN '撤销验收' WHEN 'received' THEN '撤销收货 '||NEW.quantity WHEN 'stocked' THEN '撤销入库 '||NEW.quantity END ||' · 原因：'||NEW.reason,NEW.actor_id,NEW.actor_name,NEW.created_at FROM order_items WHERE id=NEW.item_id;
END;
CREATE TRIGGER item_correction_no_update BEFORE UPDATE ON item_corrections BEGIN SELECT RAISE(ABORT,'更正记录不可覆盖'); END;
CREATE TRIGGER item_correction_no_delete BEFORE DELETE ON item_corrections BEGIN SELECT RAISE(ABORT,'更正记录不可删除'); END;
CREATE TRIGGER po_identity_fixed BEFORE UPDATE OF id ON purchase_orders
WHEN NEW.id IS NOT OLD.id
BEGIN SELECT RAISE(ABORT, 'PO order identity is immutable'); END;
CREATE TRIGGER packaging_volume_history AFTER UPDATE OF packaging_volume ON order_items
WHEN NEW.packaging_volume != OLD.packaging_volume BEGIN
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at)
 SELECT lower(hex(randomblob(16))),NEW.order_id,'packaging_volume',NEW.product_name||' · 包装体积：'||
 CASE WHEN OLD.packaging_volume='' THEN '待填写' ELSE OLD.packaging_volume END ||' → '||
 CASE WHEN NEW.packaging_volume='' THEN '待填写' ELSE NEW.packaging_volume END ,
 NEW.packaging_volume_by,name,NEW.packaging_volume_at FROM users WHERE id=NEW.packaging_volume_by;
END;
CREATE TRIGGER production_photo_delete_recheck AFTER UPDATE OF deleted_at ON attachments
WHEN OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL BEGIN
 UPDATE order_items SET acceptance_status='pending',production_revision=production_revision+1 WHERE id=NEW.item_id;
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at)
 SELECT lower(hex(randomblob(16))),NEW.order_id,'photo_deleted','删除错误实拍照片：'||NEW.file_name,NEW.deleted_by,name,NEW.deleted_at FROM users WHERE id=NEW.deleted_by;
END;
CREATE TRIGGER production_photo_delete_guard BEFORE UPDATE OF deleted_at ON attachments
WHEN NEW.deleted_at IS NOT OLD.deleted_at AND (
 OLD.deleted_at IS NOT NULL OR NEW.deleted_at IS NULL OR OLD.kind!='production_photo'
 OR NOT (
  EXISTS(SELECT 1 FROM staff_roles WHERE user_id=NEW.deleted_by AND role='admin')
  OR EXISTS(SELECT 1 FROM staff_permissions WHERE user_id=NEW.deleted_by AND supplier_operations=1)
 )
 OR NOT EXISTS(SELECT 1 FROM order_items i JOIN purchase_orders p ON p.id=i.order_id WHERE i.id=OLD.item_id AND i.shipped_quantity=0 AND p.archived_at IS NULL)
)
BEGIN SELECT RAISE(ABORT,'实拍照片已锁定或无权删除'); END;
CREATE TRIGGER warehouse_record_guard BEFORE INSERT ON warehouse_records
WHEN NOT EXISTS (
 SELECT 1 FROM order_items i JOIN purchase_orders po ON po.id=i.order_id
 WHERE i.id=NEW.item_id AND i.order_id=NEW.order_id AND po.archived_at IS NULL
 AND (
  (EXISTS(SELECT 1 FROM staff_roles WHERE user_id=NEW.actor_id AND role='admin')
   AND ((NEW.action='received' AND NEW.quantity<=i.quantity-i.received_quantity)
    OR (NEW.action='stocked' AND NEW.quantity<=i.received_quantity-i.stocked_quantity)))
  OR (po.status IN ('ready_to_ship','shipped','received','completed')
   AND ((NEW.action='received' AND NEW.quantity<=i.shipped_quantity-i.received_quantity)
    OR (NEW.action='stocked' AND NEW.quantity<=i.received_quantity-i.stocked_quantity)))
 )
)
BEGIN SELECT RAISE(ABORT,'仓库数量超过可登记数量或订单已锁定'); END;
CREATE TRIGGER shipment_acceptance_guard BEFORE INSERT ON shipment_items
WHEN NOT EXISTS (
  SELECT 1
  FROM order_items i
  JOIN purchase_orders po ON po.id = i.order_id
  JOIN suppliers s ON s.id = po.supplier_id
  WHERE i.id = NEW.item_id AND (i.acceptance_status = 'approved' OR s.is_online_purchase = 1)
)
BEGIN SELECT RAISE(ABORT, '产品未通过采购验收，不能发货'); END;
CREATE TRIGGER warehouse_receipt_quantity_guard BEFORE UPDATE ON warehouse_receipts
WHEN NEW.stocked_quantity>NEW.received_quantity-NEW.cancelled_quantity
BEGIN SELECT RAISE(ABORT,'仓库批次数量不一致'); END;
CREATE TRIGGER warehouse_receipt_action_guard BEFORE INSERT ON warehouse_receipt_actions
WHEN NOT EXISTS(SELECT 1 FROM warehouse_receipts r JOIN purchase_orders p ON p.id=r.order_id
 WHERE r.id=NEW.receipt_id AND p.archived_at IS NULL AND r.revision=NEW.expected_revision
 AND r.received_quantity>r.cancelled_quantity
 AND ((NEW.action IN ('passed','exception') AND r.status='pending_inspection')
 OR (NEW.action='resolve' AND r.status='exception' AND length(trim(NEW.note))>0))
 AND (NEW.action!='exception' OR (NEW.exception_type IN ('shortage','overage','wrong_item','damaged','specification','other') AND typeof(NEW.exception_quantity)='integer' AND NEW.exception_quantity BETWEEN 1 AND r.received_quantity-r.cancelled_quantity AND length(trim(NEW.note))>0)))
BEGIN SELECT RAISE(ABORT,'仓库验收状态已变化，请刷新核对'); END;
CREATE TRIGGER warehouse_receipt_action_apply AFTER INSERT ON warehouse_receipt_actions BEGIN
 UPDATE warehouse_receipts SET status= CASE WHEN NEW.action='resolve' THEN 'pending_inspection' ELSE NEW.action END ,
 exception_type= CASE WHEN NEW.action='exception' THEN NEW.exception_type ELSE NULL END ,
 exception_quantity= CASE WHEN NEW.action='exception' THEN NEW.exception_quantity ELSE NULL END ,
 exception_notes= CASE WHEN NEW.action='exception' THEN NEW.note ELSE '' END ,
 inspected_at= CASE WHEN NEW.action='resolve' THEN NULL ELSE NEW.created_at END ,
 inspected_by= CASE WHEN NEW.action='resolve' THEN NULL ELSE NEW.actor_name END ,
 revision=revision+1,updated_at=NEW.created_at WHERE id=NEW.receipt_id;
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at)
 SELECT NEW.id,order_id, CASE NEW.action WHEN 'resolve' THEN 'warehouse_exception_resolved' WHEN 'passed' THEN 'warehouse_inspection_passed' ELSE 'warehouse_exception' END ,
 CASE NEW.action WHEN 'resolve' THEN '异常已处理，等待仓库复验：' WHEN 'passed' THEN '仓库验收通过，等待入库' ELSE '仓库验收异常：' END ||NEW.note,NEW.actor_id,NEW.actor_name,NEW.created_at FROM warehouse_receipts WHERE id=NEW.receipt_id;
END;
CREATE TRIGGER warehouse_receipt_action_no_update BEFORE UPDATE ON warehouse_receipt_actions BEGIN SELECT RAISE(ABORT,'验收处理记录不可覆盖'); END;
CREATE TRIGGER warehouse_receipt_action_no_delete BEFORE DELETE ON warehouse_receipt_actions BEGIN SELECT RAISE(ABORT,'验收处理记录不可删除'); END;
CREATE TRIGGER warehouse_stock_batch_guard BEFORE INSERT ON warehouse_records
WHEN NEW.action='stocked' AND NOT EXISTS(SELECT 1 FROM warehouse_receipts r WHERE r.id=NEW.receipt_id AND r.item_id=NEW.item_id AND r.order_id=NEW.order_id AND r.status='passed'
 AND NEW.quantity<=r.received_quantity-r.cancelled_quantity-r.stocked_quantity
 AND length(trim(NEW.warehouse_name))>0 AND length(trim(NEW.storage_location))>0
 AND (r.stocked_quantity=0 OR (r.warehouse_name=NEW.warehouse_name AND r.storage_location=NEW.storage_location)))
BEGIN SELECT RAISE(ABORT,'仓库入库必须选择已验收批次及仓库库位'); END;
CREATE TRIGGER warehouse_stock_batch_apply AFTER INSERT ON warehouse_records WHEN NEW.action='stocked' BEGIN
 UPDATE warehouse_receipts SET stocked_quantity=stocked_quantity+NEW.quantity,
 status= CASE WHEN stocked_quantity+NEW.quantity=received_quantity-cancelled_quantity THEN 'stocked' ELSE 'passed' END ,
 warehouse_name=NEW.warehouse_name,storage_location=NEW.storage_location,stocked_at=NEW.created_at,stocked_by=NEW.actor_name,revision=revision+1,updated_at=NEW.created_at WHERE id=NEW.receipt_id;
END;
CREATE TRIGGER item_correction_batch_guard BEFORE INSERT ON item_corrections WHEN NEW.action IN ('received','stocked') AND (
 (SELECT COALESCE(SUM(received_quantity-cancelled_quantity),0) FROM warehouse_receipts WHERE item_id=NEW.item_id)!=NEW.expected_received
 OR (SELECT COALESCE(SUM(stocked_quantity),0) FROM warehouse_receipts WHERE item_id=NEW.item_id)!=NEW.expected_stocked)
BEGIN SELECT RAISE(ABORT,'更正状态与历史批次不一致，请先核对批次数量'); END;
CREATE TRIGGER item_correction_batch_apply AFTER INSERT ON item_corrections WHEN NEW.action IN ('received','stocked') BEGIN
 INSERT INTO warehouse_correction_allocations(correction_id,receipt_id,quantity)
 SELECT NEW.id,id,MIN(available,NEW.quantity-preceding) FROM (
   SELECT id, CASE NEW.action WHEN 'stocked' THEN stocked_quantity ELSE received_quantity-cancelled_quantity-stocked_quantity END AS available,
   COALESCE(SUM( CASE NEW.action WHEN 'stocked' THEN stocked_quantity ELSE received_quantity-cancelled_quantity-stocked_quantity END ) OVER (ORDER BY created_at DESC,rowid DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AS preceding
   FROM warehouse_receipts WHERE item_id=NEW.item_id
 ) WHERE available>0 AND preceding<NEW.quantity;
 UPDATE warehouse_receipts SET
 cancelled_quantity=cancelled_quantity+ CASE WHEN NEW.action='received' THEN (SELECT quantity FROM warehouse_correction_allocations WHERE correction_id=NEW.id AND receipt_id=warehouse_receipts.id) ELSE 0 END ,
 stocked_quantity=stocked_quantity- CASE WHEN NEW.action='stocked' THEN (SELECT quantity FROM warehouse_correction_allocations WHERE correction_id=NEW.id AND receipt_id=warehouse_receipts.id) ELSE 0 END ,
 status= CASE WHEN NEW.action='received' AND stocked_quantity>0 AND received_quantity-cancelled_quantity-(SELECT quantity FROM warehouse_correction_allocations WHERE correction_id=NEW.id AND receipt_id=warehouse_receipts.id)=stocked_quantity THEN 'stocked'
 WHEN NEW.action='stocked' AND status='stocked' THEN 'passed' ELSE status END ,
 revision=revision+1,updated_at=NEW.created_at
 WHERE id IN (SELECT receipt_id FROM warehouse_correction_allocations WHERE correction_id=NEW.id);
END;
CREATE TRIGGER warehouse_correction_allocation_no_update BEFORE UPDATE ON warehouse_correction_allocations BEGIN SELECT RAISE(ABORT,'批次更正记录不可覆盖'); END;
CREATE TRIGGER warehouse_correction_allocation_no_delete BEFORE DELETE ON warehouse_correction_allocations BEGIN SELECT RAISE(ABORT,'批次更正记录不可删除'); END;
CREATE TRIGGER shipment_correction_insert_guard BEFORE INSERT ON shipment_quantity_corrections
WHEN (NEW.requires_warehouse=0 AND EXISTS(SELECT 1 FROM order_items WHERE id=NEW.item_id AND (received_quantity>0 OR stocked_quantity>0)))
 OR NEW.status!='pending' OR NEW.delta_quantity!=NEW.corrected_quantity-NEW.previous_quantity
 OR EXISTS(SELECT 1 FROM shipment_quantity_corrections WHERE shipment_id=NEW.shipment_id AND item_id=NEW.item_id AND status='pending')
 OR NOT EXISTS(SELECT 1 FROM shipment_items si JOIN order_items i ON i.id=si.item_id JOIN purchase_orders p ON p.id=i.order_id
 WHERE si.shipment_id=NEW.shipment_id AND si.item_id=NEW.item_id AND i.order_id=NEW.order_id AND p.archived_at IS NULL AND p.status!='completed'
 AND si.quantity+COALESCE((SELECT SUM(delta_quantity) FROM shipment_quantity_corrections WHERE shipment_id=NEW.shipment_id AND item_id=NEW.item_id AND status='applied'),0)=NEW.previous_quantity
 AND i.shipped_quantity+NEW.delta_quantity BETWEEN i.received_quantity AND i.quantity)
BEGIN SELECT RAISE(ABORT,'发货更正状态已变化或数量超出范围'); END;
CREATE TRIGGER shipment_correction_decision_guard BEFORE UPDATE ON shipment_quantity_corrections
WHEN OLD.status!='pending' OR NEW.status NOT IN ('applied','rejected')
 OR NEW.order_id!=OLD.order_id OR NEW.shipment_id!=OLD.shipment_id OR NEW.item_id!=OLD.item_id
 OR NEW.previous_quantity!=OLD.previous_quantity OR NEW.corrected_quantity!=OLD.corrected_quantity OR NEW.delta_quantity!=OLD.delta_quantity
 OR NEW.requires_warehouse!=OLD.requires_warehouse OR NEW.reason!=OLD.reason OR NEW.requested_by!=OLD.requested_by OR NEW.requested_at!=OLD.requested_at
 OR NEW.decided_by IS NULL OR NEW.decided_at IS NULL
 OR (NEW.status='applied' AND NOT EXISTS(SELECT 1 FROM order_items i JOIN purchase_orders p ON p.id=i.order_id
 WHERE i.id=NEW.item_id AND p.archived_at IS NULL AND p.status!='completed'
 AND i.shipped_quantity+NEW.delta_quantity BETWEEN i.received_quantity AND i.quantity
 AND NEW.previous_quantity=(SELECT quantity FROM shipment_items WHERE shipment_id=NEW.shipment_id AND item_id=NEW.item_id)+COALESCE((SELECT SUM(delta_quantity) FROM shipment_quantity_corrections WHERE shipment_id=NEW.shipment_id AND item_id=NEW.item_id AND status='applied'),0)))
BEGIN SELECT RAISE(ABORT,'发货更正状态已变化或数量超出范围'); END;
CREATE TRIGGER shipment_correction_apply AFTER UPDATE ON shipment_quantity_corrections BEGIN
 UPDATE order_items SET shipped_quantity=shipped_quantity+NEW.delta_quantity,
 workflow_stage= CASE WHEN shipped_quantity+NEW.delta_quantity=quantity THEN 'shipment_complete' WHEN workflow_stage='shipment_complete' THEN 'ready_to_ship' ELSE workflow_stage END
 WHERE id=NEW.item_id AND NEW.status='applied';
 UPDATE purchase_orders SET
 status= CASE WHEN NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=NEW.order_id AND shipped_quantity<quantity) THEN 'shipped' ELSE 'ready_to_ship' END ,
 shipment_status= CASE WHEN NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=NEW.order_id AND shipped_quantity>0) THEN 'none' WHEN NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=NEW.order_id AND shipped_quantity<quantity) THEN 'complete' ELSE 'partial' END ,
 shipped_at= CASE WHEN NOT EXISTS(SELECT 1 FROM order_items WHERE order_id=NEW.order_id AND shipped_quantity>0) THEN NULL ELSE shipped_at END ,
 updated_at=NEW.decided_at WHERE id=NEW.order_id AND NEW.status='applied';
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at) VALUES
 (NEW.id,NEW.order_id, CASE NEW.status WHEN 'applied' THEN 'shipment_corrected' ELSE 'shipment_correction_rejected' END ,
 CASE NEW.status WHEN 'applied' THEN '更正发货数量：'||NEW.previous_quantity||' → '||NEW.corrected_quantity||' 件；' ELSE '驳回发货更正：' END ||NEW.reason||'；'||COALESCE(NEW.decision_note,''),NEW.decided_by,NEW.decided_by_name,NEW.decided_at);
END;
CREATE TRIGGER shipment_correction_no_delete BEFORE DELETE ON shipment_quantity_corrections BEGIN SELECT RAISE(ABORT,'发货更正记录不可删除'); END;
CREATE TRIGGER settlement_revision AFTER UPDATE ON order_settlements WHEN NEW.revision=OLD.revision BEGIN
 UPDATE order_settlements SET revision=revision+1 WHERE order_id=NEW.order_id;
END;
CREATE TRIGGER warehouse_reconciliation_guard BEFORE INSERT ON warehouse_batch_reconciliations
WHEN NOT EXISTS(SELECT 1 FROM order_items i JOIN purchase_orders p ON p.id=i.order_id WHERE i.id=NEW.item_id AND i.order_id=NEW.order_id AND p.archived_at IS NULL AND i.received_quantity=NEW.expected_received AND i.stocked_quantity=NEW.expected_stocked)
 OR json_array_length(NEW.allocations_json)!=(SELECT COUNT(*) FROM warehouse_receipts WHERE item_id=NEW.item_id)
 OR (SELECT COUNT(DISTINCT json_extract(value,'$.id')) FROM json_each(NEW.allocations_json))!=json_array_length(NEW.allocations_json)
 OR EXISTS(SELECT 1 FROM json_each(NEW.allocations_json) a LEFT JOIN warehouse_receipts r ON r.id=json_extract(a.value,'$.id') AND r.item_id=NEW.item_id
 WHERE r.id IS NULL OR r.revision!=json_extract(a.value,'$.revision')
 OR json_type(a.value,'$.received')!='integer' OR json_type(a.value,'$.stocked')!='integer'
 OR json_extract(a.value,'$.received') NOT BETWEEN 0 AND r.received_quantity
 OR json_extract(a.value,'$.stocked') NOT BETWEEN 0 AND json_extract(a.value,'$.received'))
 OR (SELECT SUM(json_extract(value,'$.received')) FROM json_each(NEW.allocations_json))!=NEW.expected_received
 OR (SELECT SUM(json_extract(value,'$.stocked')) FROM json_each(NEW.allocations_json))!=NEW.expected_stocked
BEGIN SELECT RAISE(ABORT,'批次数量核对失败或状态已变化'); END;
CREATE TRIGGER warehouse_reconciliation_apply AFTER INSERT ON warehouse_batch_reconciliations BEGIN
 UPDATE warehouse_receipts SET
 cancelled_quantity=received_quantity-(SELECT json_extract(value,'$.received') FROM json_each(NEW.allocations_json) WHERE json_extract(value,'$.id')=warehouse_receipts.id),
 stocked_quantity=(SELECT json_extract(value,'$.stocked') FROM json_each(NEW.allocations_json) WHERE json_extract(value,'$.id')=warehouse_receipts.id),
 status= CASE WHEN (SELECT json_extract(value,'$.stocked')>0 AND json_extract(value,'$.stocked')=json_extract(value,'$.received') FROM json_each(NEW.allocations_json) WHERE json_extract(value,'$.id')=warehouse_receipts.id) THEN 'stocked' WHEN status='stocked' THEN 'pending_inspection' ELSE status END ,
 revision=revision+1,updated_at=NEW.created_at WHERE item_id=NEW.item_id;
 INSERT INTO order_events(id,order_id,event_type,detail,actor_id,actor_name,created_at) VALUES (NEW.id,NEW.order_id,'warehouse_reconciled','历史批次数量核对：'||NEW.reason,NEW.actor_id,NEW.actor_name,NEW.created_at);
END;
CREATE TRIGGER warehouse_reconciliation_no_update BEFORE UPDATE ON warehouse_batch_reconciliations BEGIN SELECT RAISE(ABORT,'批次核对记录不可覆盖'); END;
CREATE TRIGGER warehouse_reconciliation_no_delete BEFORE DELETE ON warehouse_batch_reconciliations BEGIN SELECT RAISE(ABORT,'批次核对记录不可删除'); END;
CREATE TRIGGER warehouse_stock_balance_guard BEFORE INSERT ON warehouse_records WHEN NEW.action='stocked' AND (
 (SELECT COALESCE(SUM(received_quantity-cancelled_quantity),0) FROM warehouse_receipts WHERE item_id=NEW.item_id)!=(SELECT received_quantity FROM order_items WHERE id=NEW.item_id)
 OR (SELECT COALESCE(SUM(stocked_quantity),0) FROM warehouse_receipts WHERE item_id=NEW.item_id)!=(SELECT stocked_quantity FROM order_items WHERE id=NEW.item_id))
BEGIN SELECT RAISE(ABORT,'仓库历史批次数量不一致，请先核对'); END;
CREATE TRIGGER supplier_keep_identity BEFORE DELETE ON suppliers
BEGIN SELECT RAISE(ABORT, 'Archive suppliers instead of deleting'); END;
CREATE TRIGGER product_catalog_insert AFTER INSERT ON catalog_products BEGIN
 INSERT INTO products(id,sku,name,english_name,specification,unit,image_key,created_at) VALUES(NEW.id,NEW.sku,NEW.name,NEW.english_name,NEW.specification,NEW.unit,NEW.image_key,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(id) DO UPDATE SET sku=NEW.sku,name=NEW.name,english_name=NEW.english_name,specification=NEW.specification,unit=NEW.unit,image_key=NEW.image_key;
END;
CREATE TRIGGER product_catalog_update AFTER UPDATE ON catalog_products BEGIN
 UPDATE products SET sku=NEW.sku,name=COALESCE((SELECT name FROM product_overrides WHERE product_id=NEW.id),NEW.name),specification=COALESCE((SELECT specification FROM product_overrides WHERE product_id=NEW.id),NEW.specification),unit=COALESCE((SELECT unit FROM product_overrides WHERE product_id=NEW.id),NEW.unit),english_name=NEW.english_name,image_key=NEW.image_key WHERE id=NEW.id;
END;
CREATE TRIGGER product_override_insert AFTER INSERT ON product_overrides BEGIN
 UPDATE products SET name=COALESCE(NEW.name,name),specification=COALESCE(NEW.specification,specification),unit=COALESCE(NEW.unit,unit) WHERE id=NEW.product_id;
END;
CREATE TRIGGER product_override_update AFTER UPDATE ON product_overrides BEGIN
 UPDATE products SET name=COALESCE(NEW.name,(SELECT name FROM catalog_products WHERE id=NEW.product_id)),specification=COALESCE(NEW.specification,(SELECT specification FROM catalog_products WHERE id=NEW.product_id)),unit=COALESCE(NEW.unit,(SELECT unit FROM catalog_products WHERE id=NEW.product_id)) WHERE id=NEW.product_id;
END;
CREATE TRIGGER quotation_project_context AFTER INSERT ON quotation_history BEGIN
 UPDATE quotation_history SET project_id=json_extract(NEW.snapshot_json,'$.workspaceProjectId'),document_type=COALESCE(json_extract(NEW.snapshot_json,'$.workspaceDocumentKind'),'original'),parent_order_id=json_extract(NEW.snapshot_json,'$.workspaceParentOrderId') WHERE id=NEW.id;
END;
CREATE TRIGGER locked_quote_update BEFORE UPDATE ON quotation_history WHEN OLD.ordered_at IS NOT NULL AND (NEW.snapshot_json IS NOT OLD.snapshot_json OR NEW.contract_no IS NOT OLD.contract_no OR NEW.project_id IS NOT OLD.project_id OR NEW.final_amount IS NOT OLD.final_amount OR NEW.final_currency IS NOT OLD.final_currency OR NEW.is_finalized IS NOT OLD.is_finalized OR NEW.voided_at IS NOT OLD.voided_at OR NEW.archived_at IS NOT OLD.archived_at OR NEW.ordered_at IS NOT OLD.ordered_at) BEGIN SELECT RAISE(ABORT,'已下单报价锁定，请创建增项或变更记录'); END;
CREATE TRIGGER locked_quote_delete BEFORE DELETE ON quotation_history WHEN OLD.ordered_at IS NOT NULL BEGIN SELECT RAISE(ABORT,'已下单报价不可删除'); END;
CREATE TRIGGER baseline_no_update BEFORE UPDATE ON order_baselines BEGIN SELECT RAISE(ABORT,'成交基线不可覆盖'); END;
CREATE TRIGGER baseline_no_delete BEFORE DELETE ON order_baselines BEGIN SELECT RAISE(ABORT,'成交基线不可删除'); END;
CREATE TRIGGER baseline_line_no_update BEFORE UPDATE ON baseline_lines BEGIN SELECT RAISE(ABORT,'成交明细不可覆盖'); END;
CREATE TRIGGER po_guard_no_unlinked_item BEFORE INSERT ON order_items WHEN NEW.product_id IS NULL BEGIN SELECT RAISE(ABORT,'请先关联共用产品，再建立采购明细'); END;
CREATE TRIGGER stock_guard BEFORE INSERT ON stock_movements WHEN (SELECT COALESCE(SUM(quantity),0) FROM stock_movements WHERE product_id=NEW.product_id)+NEW.quantity < -0.000001 BEGIN SELECT RAISE(ABORT,'库存不足，不能扣成负数'); END;
CREATE TRIGGER stock_no_update BEFORE UPDATE ON stock_movements BEGIN SELECT RAISE(ABORT,'库存流水不可覆盖'); END;
CREATE TRIGGER stock_no_delete BEFORE DELETE ON stock_movements BEGIN SELECT RAISE(ABORT,'库存流水不可删除'); END;
CREATE TRIGGER stock_receipt_guard BEFORE UPDATE OF stocked_quantity ON order_items WHEN NEW.stocked_quantity!=OLD.stocked_quantity AND NEW.product_id IS NULL BEGIN SELECT RAISE(ABORT,'入库前必须关联共用产品'); END;
CREATE TRIGGER stock_receipt AFTER UPDATE OF stocked_quantity ON order_items WHEN NEW.stocked_quantity!=OLD.stocked_quantity BEGIN
 INSERT INTO stock_movements(id,product_id,quantity,kind,order_item_id,note,actor_id,created_at) VALUES(lower(hex(randomblob(16))),NEW.product_id,NEW.stocked_quantity-OLD.stocked_quantity,'receipt',NEW.id,'采购入库／入库更正',NEW.stocked_by,strftime('%Y-%m-%dT%H:%M:%fZ','now'));
END;
CREATE TRIGGER stock_item_identity_guard BEFORE UPDATE OF product_id ON order_items WHEN OLD.stocked_quantity>0 AND NEW.product_id IS NOT OLD.product_id BEGIN SELECT RAISE(ABORT,'已入库产品不能直接换型'); END;
CREATE TRIGGER customer_finance_no_update BEFORE UPDATE ON customer_financial_entries BEGIN SELECT RAISE(ABORT,'财务记录只能追加冲销'); END;
CREATE TRIGGER customer_finance_no_delete BEFORE DELETE ON customer_financial_entries BEGIN SELECT RAISE(ABORT,'财务记录不能删除'); END;
CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_events BEGIN SELECT RAISE(ABORT,'操作历史不可覆盖'); END;
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_events BEGIN SELECT RAISE(ABORT,'操作历史不可删除'); END;
CREATE TRIGGER baseline_line_no_delete BEFORE DELETE ON baseline_lines BEGIN SELECT RAISE(ABORT,'成交明细不可删除'); END;
CREATE TRIGGER locked_quote_context BEFORE UPDATE ON quotation_history WHEN OLD.ordered_at IS NOT NULL AND (NEW.document_type IS NOT OLD.document_type OR NEW.parent_order_id IS NOT OLD.parent_order_id OR NEW.project_name IS NOT OLD.project_name) BEGIN SELECT RAISE(ABORT,'已下单报价身份不可修改'); END;
CREATE TRIGGER stock_available_guard BEFORE INSERT ON stock_movements WHEN COALESCE((SELECT SUM(quantity) FROM stock_movements WHERE product_id=NEW.product_id),0)+NEW.quantity < COALESCE((SELECT SUM(quantity) FROM stock_reservations WHERE product_id=NEW.product_id AND status='active'),0)-0.000001 BEGIN SELECT RAISE(ABORT,'库存已被占用，不能撤销或扣减该数量'); END;
CREATE TRIGGER purchase_change_guard BEFORE INSERT ON purchase_item_changes WHEN NOT EXISTS(SELECT 1 FROM order_changes c JOIN order_items i ON i.baseline_line_id=c.baseline_line_id JOIN employees e ON e.id=NEW.actor_id WHERE c.id=NEW.change_id AND c.status='confirmed' AND i.id=NEW.item_id AND e.role='purchasing' AND e.status='active' AND i.product_id=NEW.old_product AND i.model=NEW.old_model AND i.quantity=NEW.old_quantity AND i.unit_price=NEW.old_price AND c.new_product_id=NEW.new_product AND c.new_model=NEW.new_model AND NEW.new_quantity>0 AND NEW.new_price>=0 AND i.shipped_quantity=0 AND i.received_quantity=0 AND i.stocked_quantity=0 AND i.production_completed=0) BEGIN SELECT RAISE(ABORT,'采购变更与销售确认或当前执行状态不一致'); END;
CREATE TRIGGER item_commercial_fields_fixed BEFORE UPDATE OF id,order_id,quantity,unit_price,amount,product_id,model ON order_items WHEN (NEW.id IS NOT OLD.id OR NEW.order_id IS NOT OLD.order_id OR NEW.quantity IS NOT OLD.quantity OR NEW.unit_price IS NOT OLD.unit_price OR NEW.amount IS NOT OLD.amount OR NEW.product_id IS NOT OLD.product_id OR (OLD.baseline_line_id IS NOT NULL AND NEW.model IS NOT OLD.model)) AND NOT EXISTS(SELECT 1 FROM purchase_item_changes c WHERE c.item_id=OLD.id AND c.applied=0 AND c.old_quantity=OLD.quantity AND c.old_price=OLD.unit_price AND c.old_product=OLD.product_id AND c.new_quantity=NEW.quantity AND c.new_price=NEW.unit_price AND c.new_product=NEW.product_id AND c.new_model=NEW.model AND NEW.id=OLD.id AND NEW.order_id=OLD.order_id AND abs(NEW.amount-NEW.quantity*NEW.unit_price)<0.00001) BEGIN SELECT RAISE(ABORT,'采购数量与型号须从销售确认的变更单执行'); END;
CREATE TRIGGER purchase_change_apply AFTER INSERT ON purchase_item_changes BEGIN
 UPDATE order_items SET product_id=NEW.new_product,product_name=NEW.new_name,model=NEW.new_model,quantity=NEW.new_quantity,unit_price=NEW.new_price,amount=NEW.new_quantity*NEW.new_price,unit=NEW.new_unit WHERE id=NEW.item_id;
 UPDATE purchase_item_changes SET applied=1 WHERE id=NEW.id;
END;
CREATE TRIGGER purchase_change_no_delete BEFORE DELETE ON purchase_item_changes BEGIN SELECT RAISE(ABORT,'采购变更记录不可删除'); END;
CREATE TRIGGER purchase_change_immutable BEFORE UPDATE ON purchase_item_changes WHEN OLD.applied=1 OR NEW.applied!=1 OR NEW.id!=OLD.id OR NEW.item_id!=OLD.item_id OR NEW.change_id!=OLD.change_id OR NEW.new_quantity!=OLD.new_quantity OR NEW.new_price!=OLD.new_price OR NEW.new_product!=OLD.new_product OR NEW.new_model!=OLD.new_model BEGIN SELECT RAISE(ABORT,'采购变更记录不可覆盖'); END;
CREATE TRIGGER deposit_no_update BEFORE UPDATE ON deposit_confirmations BEGIN SELECT RAISE(ABORT,'到账确认不可覆盖'); END;
CREATE TRIGGER deposit_no_delete BEFORE DELETE ON deposit_confirmations BEGIN SELECT RAISE(ABORT,'到账确认不可删除'); END;
CREATE TRIGGER executed_purchase_archive_guard BEFORE UPDATE OF archived_at ON purchase_orders WHEN OLD.archived_at IS NULL AND NEW.archived_at IS NOT NULL AND EXISTS(SELECT 1 FROM order_items WHERE order_id=OLD.id AND (production_completed>0 OR shipped_quantity>0 OR received_quantity>0 OR stocked_quantity>0)) BEGIN SELECT RAISE(ABORT,'采购已有实际执行，须先核对实物处理，不能直接作废后重复采购'); END;
CREATE TRIGGER engineering_lock BEFORE UPDATE ON engineering_orders WHEN OLD.status='released' BEGIN SELECT RAISE(ABORT,'已下达工程单保留原版本，请新建修订'); END;
CREATE TRIGGER stock_location_guard BEFORE INSERT ON stock_movements WHEN (SELECT COALESCE(SUM(quantity),0) FROM stock_movements WHERE product_id=NEW.product_id AND location_id=NEW.location_id)+NEW.quantity < -0.000001 BEGIN SELECT RAISE(ABORT,'该库位库存不足，请核对存放位置后再处理'); END;
CREATE TRIGGER stock_usable_guard BEFORE INSERT ON stock_movements WHEN (SELECT usable FROM warehouse_locations WHERE id=NEW.location_id)=1 AND (SELECT COALESCE(SUM(m.quantity),0) FROM stock_movements m JOIN warehouse_locations l ON l.id=m.location_id WHERE m.product_id=NEW.product_id AND l.usable=1)+NEW.quantity < (SELECT COALESCE(SUM(quantity),0) FROM stock_reservations WHERE product_id=NEW.product_id AND status='active')-0.000001 BEGIN SELECT RAISE(ABORT,'可用库存已被占用，请先核对客户或售后占用'); END;
CREATE TRIGGER center_events_no_update BEFORE UPDATE ON center_events BEGIN SELECT RAISE(ABORT,'业务过程记录不可覆盖'); END;
CREATE TRIGGER center_events_no_delete BEFORE DELETE ON center_events BEGIN SELECT RAISE(ABORT,'业务过程记录不可删除'); END;
