/* Route the original module API calls through their same-origin mount. */
(() => {
  const match = location.pathname.match(/^\/modules\/(quote|procurement|aftersales)(?:\/|$)/);
  if (!match) return;
  const base = '/modules/' + match[1];
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input, options) => {
    const url = new URL(input instanceof Request ? input.url : input, location.href);
    if (url.origin === location.origin && url.pathname.startsWith('/api/')) {
      url.pathname = base + url.pathname;
      input = input instanceof Request ? new Request(url, input) : url.toString();
    }
    return nativeFetch(input, options);
  };
  function patch(element) {
    for (const attribute of ['src', 'href', 'action']) {
      const value = element.getAttribute(attribute);
      if (value?.startsWith('/') && !value.startsWith('//') && !value.startsWith('/modules/')) element.setAttribute(attribute, base + value);
    }
  }
  // React creates image/download links after the initial server HTML response.
  new MutationObserver(records => {
    for (const record of records) {
      if (record.type === 'attributes') patch(record.target);
      for (const node of record.addedNodes) if (node instanceof Element) {
        patch(node); node.querySelectorAll('[src],[href],[action]').forEach(patch);
      }
    }
  }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['src','href','action'] });
})();
