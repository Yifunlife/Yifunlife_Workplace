CREATE TABLE `af2_customer_files` (
	`id` text PRIMARY KEY NOT NULL,
	`request_id` text NOT NULL,
	`object_key` text NOT NULL,
	`name` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	FOREIGN KEY (`request_id`) REFERENCES `af2_customer_requests`(`id`) ON UPDATE no action ON DELETE no action
);

CREATE TABLE `af2_customer_invites` (
	`id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`token_hash` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`expires` integer NOT NULL,
	`created_by` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `af2_customer_profiles`(`id`) ON UPDATE no action ON DELETE no action
);

CREATE UNIQUE INDEX `af2_customer_invite_token_unique` ON `af2_customer_invites` (`token_hash`);
CREATE TABLE `af2_customer_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`market_id` text,
	`company` text NOT NULL,
	`contact` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`country` text NOT NULL,
	`language` text NOT NULL,
	`sales_owner` text NOT NULL,
	`updated_at` integer NOT NULL
);

CREATE UNIQUE INDEX `af2_customer_market_id_unique` ON `af2_customer_profiles` (`market_id`);
CREATE TABLE `af2_customer_rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`attempts` integer NOT NULL,
	`until` integer NOT NULL
);

CREATE TABLE `af2_customer_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`store_id` text NOT NULL,
	`invite_id` text NOT NULL,
	`submission_key` text NOT NULL,
	`status` text NOT NULL,
	`payload` text NOT NULL,
	`note` text NOT NULL,
	`reviewer_id` text,
	`checked_by` text,
	`submitted_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `af2_customer_profiles`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`store_id`) REFERENCES `af2_customer_stores`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`invite_id`) REFERENCES `af2_customer_invites`(`id`) ON UPDATE no action ON DELETE no action
);

CREATE UNIQUE INDEX `af2_customer_request_submission_unique` ON `af2_customer_requests` (`invite_id`,`submission_key`);
CREATE TABLE `af2_customer_stores` (
	`id` text PRIMARY KEY NOT NULL,
	`customer_id` text NOT NULL,
	`market_id` text,
	`name` text NOT NULL,
	`order_no` text NOT NULL,
	`address` text NOT NULL,
	`contact` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`customer_id`) REFERENCES `af2_customer_profiles`(`id`) ON UPDATE no action ON DELETE no action
);

CREATE UNIQUE INDEX `store_market_id_unique` ON `af2_customer_stores` (`market_id`);
CREATE TABLE `af2_customer_work_items` (
	`id` text PRIMARY KEY NOT NULL,
	`request_id` text NOT NULL,
	`payload` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`updated_at` integer NOT NULL,
	`updated_by` text NOT NULL,
	FOREIGN KEY (`request_id`) REFERENCES `af2_customer_requests`(`id`) ON UPDATE no action ON DELETE no action
);

CREATE TABLE af2_account_audit(id TEXT PRIMARY KEY,actor TEXT,target TEXT,action TEXT,at INTEGER);
CREATE TABLE af2_ownership(entity TEXT NOT NULL,id TEXT NOT NULL,owner_id TEXT NOT NULL,PRIMARY KEY(entity,id));

CREATE TABLE af2_ticket_links(ticket_id TEXT PRIMARY KEY REFERENCES service_tickets(id),core_version INTEGER NOT NULL);
