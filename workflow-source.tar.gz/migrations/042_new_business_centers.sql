ALTER TABLE center_members RENAME TO center_members_previous;
CREATE TABLE center_members(employee_id TEXT NOT NULL REFERENCES employees(id),center TEXT NOT NULL CHECK(center IN ('marketing','design','product_rd','software','brand_visual')),PRIMARY KEY(employee_id,center));
INSERT INTO center_members SELECT employee_id,center FROM center_members_previous;
DROP TABLE center_members_previous;
