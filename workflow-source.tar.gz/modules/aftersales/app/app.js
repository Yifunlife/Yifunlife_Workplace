const APP_KEY = "yifun-after-sales-local-v1";
const cloudConfig = window.AFTER_SALES_CONFIG || { enabled: false, apiBase: "" };
const STAGES = ["接收反馈", "建立售后单", "初步分析", "制定方案", "执行处理", "售后回访", "关闭与复盘"];
const ISSUE_CATEGORIES = ["软件", "配件", "主体类", "软包类", "电器类", "其他"];
const CAUSE_CATEGORIES = ["产品质量", "生产", "安装", "运输", "使用", "正常损耗", "待确认"];
const HANDLING_METHODS = ["远程指导", "维修", "更换配件", "补货", "重新生产", "其他"];
const PROCUREMENT_STATUSES = ["待采购", "询价中", "已下单", "部分到货", "已到货", "已取消"];
const CUSTOMER_ENGLISH = {
  "宁波凤鸣云翠": "Ningbo Fengming Yuncui",
  "地贴": "Floor Decal", "灯带": "LED Strip", "蹦床区": "Trampoline Area", "未填写": "Not specified",
  "磨损起皮": "The floor decal is worn and peeling.",
  "磨损，需要重新定做一个过去": "The item is worn and requires a newly manufactured replacement.",
  "这个地方的灯带已经完全脱落了；6.18再次反馈灯带基本已经全部脱落出来了": "The LED strip in this area has completely detached. On 18 June, it was reported again that most of the LED strip had come away.",
  "胶不粘了，可能需要补胶固定一下": "The adhesive is no longer holding. Additional adhesive may be required to secure it.",
  "待确认": "Pending further inspection and confirmation.", "待进一步检查确认": "Pending further inspection and confirmation.",
  "远程指导": "Remote Support", "维修": "Repair", "更换配件": "Parts Replacement", "补货": "Replacement Parts Supply", "重新生产": "Reproduction", "其他": "Other",
  "待完成": "Pending", "处理中": "In Progress", "已完成": "Completed", "中国": "China",
};

const iconPaths = {
  dashboard: '<path d="M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z"/>',
  list: '<path d="M5 6h14M5 12h14M5 18h14"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  box: '<path d="m21 16-9 5-9-5 9-5 9 5Z"/><path d="m3 12 9 5 9-5M3 8l9-5 9 5-9 5-9-5Z"/>',
  cart: '<path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 1.9-1.4L21 8H7"/><circle cx="10" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M5 20h14"/>',
  arrow: '<path d="M9 18l6-6-6-6"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
};
const icon = (name, cls = "") => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || ""}</svg>`;
const escape = (value = "") => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
const today = () => new Date().toISOString().slice(0, 10);
const now = () => new Date().toLocaleString("zh-CN", { hour12: false });
const uid = (prefix) => `${prefix}-${crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`}`;
const systemTitle = "亦玩集团售后管理系统";

const seedData = {projects:[],tickets:[],parts:[],procurements:[],versions:{},deliveries:[]};

let ticketIdMigration = new Map();
let data = loadData();
let route = "dashboard";
let currentTicketId = null;
let selectedProjectIds = new Set();
let newTicketMode = "online";
let pendingFiles = [];
let importQueue = { workbooks: [], photos: [] };

let savedTickets = new Map();
let saveQueue=Promise.resolve();
let saving=0;
let cloudReady=false;
function loadData(){return structuredClone(seedData);}
async function requestAction(action,payload){
 const response=await fetch(`/api/action/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
 const result=await response.json();if(!response.ok)throw new Error(result.error||'操作未保存');return result;
}
function saveData(){
 if(!cloudReady)return Promise.reject(new Error('资料尚未加载完成，请稍后重试'));
 const snapshot=structuredClone(data.tickets);saving++;
 const job=saveQueue.catch(()=>{}).then(async()=>{
  const records=snapshot.filter(t=>JSON.stringify(t)!==savedTickets.get(t.id)).map(t=>({id:t.id,version:data.versions[t.id]||0,payload:t}));
  if(!records.length)return;
  const response=await fetch('/api/state',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({records})});
  const result=await response.json();if(!response.ok)throw new Error(result.error||'保存失败');
  Object.assign(data.versions,result.versions);records.forEach(r=>savedTickets.set(r.id,JSON.stringify(r.payload)));
 });
 saveQueue=job.finally(()=>saving--);return saveQueue;
}
async function loadCloudData(){
 const response=await fetch('/api/state');const result=await response.json();
 if(!response.ok||!result.data)throw new Error(result.error||'无法读取共用资料');
 data=result.data;savedTickets=new Map(data.tickets.map(t=>[t.id,JSON.stringify(t)]));cloudReady=true;const link=window.location.hash.match(/^#ticket-detail\/(.+)$/);if(link){const key=decodeURIComponent(link[1]);if(data.tickets.some(t=>t.id===key)){route='ticket-detail';currentTicketId=key;}}render();
}
window.addEventListener('unhandledrejection',event=>{event.preventDefault();toast(event.reason?.message||'操作尚未保存，请重试');});
window.addEventListener('beforeunload',event=>{if(saving||data.tickets.some(t=>savedTickets.get(t.id)!==JSON.stringify(t))){event.preventDefault();event.returnValue='';}});
function statusFor(ticket) {
  if (ticket.stage === "关闭与复盘") return "已完成";
  if (["接收反馈", "建立售后单"].includes(ticket.stage)) return "待完成";
  return "处理中";
}
function statusClass(status) { return status === "已完成" ? "done" : status === "待完成" ? "pending" : "progress"; }
function projectFor(id) { return data.projects.find((project) => project.id === id); }
function nextCode(prefix, records, field = "id") {
  const year = new Date().getFullYear();
  const values = records.map((record) => Number(String(record[field] || "").match(/(\d{3,})$/)?.[1] || 0));
  return `${prefix}-${year}-${String(Math.max(0, ...values) + 1).padStart(3, "0")}`;
}
function nextTicketCode(projectId){const project=projectFor(projectId);return `AS-${project?.contractNo||'PROJECT'}-${crypto.randomUUID().slice(0,8).toUpperCase()}`;}

function optionList(items, selected = "", placeholder = "请选择") {
  return `<option value="">${placeholder}</option>${items.map((item) => `<option value="${escape(item)}" ${item === selected ? "selected" : ""}>${escape(item)}</option>`).join("")}`;
}
function setRoute(nextRoute, ticketId = null) { route = nextRoute; currentTicketId = ticketId; window.location.hash = ticketId ? `${nextRoute}/${ticketId}` : nextRoute; render(); }
function toast(message) { const node = document.querySelector("#toast"); node.textContent = message; node.classList.add("show"); clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.remove("show"), 2400); }

const photoStore = {
  ensureCloud() { if (!cloudConfig.enabled) throw new Error("云端附件存储尚未连接"); },
  async add(ticketId, file) {
    this.ensureCloud();
    const form = new FormData(); form.append("ticketId", ticketId); form.append("file", file);
    const response = await fetch(`${cloudConfig.apiBase}/api/attachments`, { method: "POST", body: form });
    if (!response.ok) throw new Error("附件上传失败");
    return response.json();
  },
  async list(ticketId) {
    if (!cloudConfig.enabled) return [];
    const response = await fetch(`${cloudConfig.apiBase}/api/attachments?ticketId=${encodeURIComponent(ticketId)}`);
    if (!response.ok) throw new Error("附件列表读取失败");
    return response.json();
  },
  async remove(photoId) {
    this.ensureCloud();
    const response = await fetch(`${cloudConfig.apiBase}/api/attachments/${encodeURIComponent(photoId)}`, { method: "DELETE" });
    if (!response.ok) throw new Error("附件删除失败");
  },
};

function appShell() {
  return `<div class="shell">
    <aside class="sidebar">
      <div class="brand"><img class="brand-logo" src="./assets/yifun-life-logo-transparent.png" width="1431" height="340" alt="Yifun Life 亦玩集团" /></div>
      <nav class="nav" aria-label="主导航">
        <button class="nav-button" data-route="dashboard" aria-label="数据看板">${icon("dashboard", "nav-icon")}<span>数据看板</span></button>
        <div class="nav-group">售后管理</div>
        <button class="nav-button" data-route="new-ticket" aria-label="创建售后单">${icon("plus", "nav-icon")}<span>创建售后单</span></button>
        <button class="nav-button" data-route="tickets" aria-label="售后问题明细">${icon("list", "nav-icon")}<span>售后问题明细</span></button>
        <button class="nav-button" data-route="customer-reports" aria-label="客户售后服务表单">${icon("folder", "nav-icon")}<span>客户售后服务表单</span></button>
        <div class="nav-group">物料管理</div>
        <button class="nav-button" data-route="parts" aria-label="配件管理">${icon("box", "nav-icon")}<span>配件管理</span></button>
        <button class="nav-button" data-route="procurements" aria-label="采购信息">${icon("cart", "nav-icon")}<span>采购信息</span></button>
      </nav>
      <div class="side-note"><strong>${cloudConfig.enabled ? "共用工作平台" : "Cloudflare 待连接"}</strong>${cloudConfig.enabled ? "项目来自统一档案；配件与采购共用库存。" : "照片不会写入本机；连接 Cloudflare R2 后才可上传。"}</div>
    </aside>
    <main class="main"><header class="topbar"><div class="crumb"><span>售后管理</span>${icon("arrow", "tiny-arrow")}<strong id="page-crumb">数据看板</strong></div><div class="profile"><span>统一售后中心</span><div class="avatar">本</div></div></header><section id="view" class="content"></section></main>
  </div>`;
}

function pageHeading(title, description, action = "") { return `<div class="page-heading"><div><h2>${title}</h2><p>${description}</p></div>${action}</div>`; }
function render() {
  if (!document.querySelector(".shell")) document.querySelector("#app").innerHTML = appShell();
  document.querySelectorAll("[data-route]").forEach((node) => node.classList.toggle("active", node.dataset.route === route));
  const view = document.querySelector("#view");
  const display = {
    dashboard: ["数据看板", renderDashboard], tickets: ["售后问题明细", renderTickets], "new-ticket": ["创建售后单", renderNewTicket], "customer-reports": ["客户售后服务表单", renderCustomerReports], parts: ["配件管理", renderParts], procurements: ["采购信息", renderProcurements], projects: ["项目档案", renderProjects], "ticket-detail": ["售后单详情", renderTicketDetail], "client-report": ["项目客户服务报告", renderClientReport],
  }[route] || ["数据看板", renderDashboard];
  document.querySelector("#page-crumb").textContent = display[0];
  if (route !== "client-report") document.title = systemTitle;
  view.innerHTML = display[1]();
  bindRoute();
  if(data.role&&data.role!=='aftersales'){
    view.querySelectorAll('form input,form select,form textarea,form button,[data-delete-photo],#show-part-form,#show-procurement-form,[data-procurement-status]').forEach(el=>{el.disabled=true;});
  }
}

function renderDashboard() {
  const tickets = data.tickets;
  const pending = tickets.filter((ticket) => statusFor(ticket) === "待完成");
  const processing = tickets.filter((ticket) => statusFor(ticket) === "处理中");
  const completed = tickets.filter((ticket) => statusFor(ticket) === "已完成");
  const unfinished = tickets.length - completed.length;
  const topProducts = aggregate(tickets, (ticket) => ticket.product || "未填写");
  const categories = aggregate(tickets, (ticket) => ticket.category || "待分类");
  const latest = [...tickets].sort((a, b) => String(b.lastUpdated).localeCompare(String(a.lastUpdated))).slice(0, 6);
  return `${pageHeading("售后数据看板", "汇总售后进度、共用配件库存与采购申请。", `<button class="button primary" data-route="new-ticket">${icon("plus", "button-icon")}创建售后单</button>`)}
    <div class="metrics">
      ${metric("售后总问题数", tickets.length, "当前售后记录", "blue")}
      ${metric("未完成", unfinished, `待完成 ${pending.length} · 处理中 ${processing.length}`, "warning")}
      ${metric("待完成", pending.length, "待接收或建立售后单", "warning")}
      ${metric("已完成", completed.length, "已关闭与复盘", "success")}
    </div>
    <div class="dashboard-grid">
      <section class="panel"><div class="panel-head"><div><div class="panel-title">当前工作状态</div><div class="panel-subtitle">状态根据售后单的当前节点自动计算</div></div><button class="button secondary small" data-route="tickets">查看全部</button></div><div class="panel-body"><div class="workflow"><div class="workflow-item pending"><span>待完成</span><strong>${pending.length}</strong><small>接收反馈 / 建立售后单</small></div><div class="workflow-item progress"><span>处理中</span><strong>${processing.length}</strong><small>分析、处理或回访中</small></div><div class="workflow-item done"><span>已完成</span><strong>${completed.length}</strong><small>关闭与复盘</small></div></div></div></section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">配件与采购</div><div class="panel-subtitle">需要关注的物料事项</div></div></div><div class="panel-body"><div class="small-kpi"><span>低库存配件</span><strong>${data.parts.filter((part) => Number(part.stock) <= Number(part.minStock || 0)).length}</strong></div><div class="small-kpi"><span>待采购 / 询价中</span><strong>${data.procurements.filter((item) => ["待采购", "询价中"].includes(item.status)).length}</strong></div><div class="small-kpi"><span>已关联采购单</span><strong>${data.procurements.filter((item) => item.ticketId).length}</strong></div></div></section>
    </div>
    <div class="dashboard-grid" style="margin-top:18px">
      <section class="panel"><div class="panel-head"><div><div class="panel-title">产品问题 TOP</div><div class="panel-subtitle">按售后问题数量统计</div></div></div><div class="panel-body">${barRows(topProducts, "blue")}</div></section>
      <section class="panel"><div class="panel-head"><div><div class="panel-title">问题分类占比</div><div class="panel-subtitle">用于快速判断问题来源</div></div></div><div class="panel-body">${barRows(categories, "amber")}</div></section>
    </div>
    <section class="panel" style="margin-top:18px"><div class="panel-head"><div><div class="panel-title">最近更新的售后单</div><div class="panel-subtitle">点击任意记录可更新工作流与附件</div></div></div>${ticketTable(latest)}</section>`;
}
function metric(label, value, note, variant = "") { return `<article class="metric ${variant}"><div class="metric-label"><span>${label}</span><i class="metric-dot"></i></div><div class="metric-value">${value}</div><div class="metric-note">${note}</div></article>`; }
function aggregate(records, selector) { return Object.entries(records.reduce((acc, item) => { const key = selector(item); acc[key] = (acc[key] || 0) + 1; return acc; }, {})).map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count).slice(0, 6); }
function barRows(items, color = "") { if (!items.length) return `<div class="empty"><strong>暂无数据</strong><p>创建售后单后会自动汇总。</p></div>`; const max = Math.max(...items.map((item) => item.count)); return `<div class="bar-list">${items.map((item) => `<div class="bar-row"><label title="${escape(item.label)}">${escape(item.label)}</label><div class="track"><div class="bar ${color}" style="width:${Math.max(8, item.count / max * 100)}%"></div></div><strong>${item.count}</strong></div>`).join("")}</div>`; }
function ticketTable(tickets) { if (!tickets.length) return `<div class="empty"><strong>还没有售后单</strong><p>可在线填写，或从已有维修表导入。</p></div>`; return `<div class="table-wrap"><table class="data-table"><thead><tr><th>售后编号</th><th>项目编号（合同号）</th><th>项目名称</th><th>产品</th><th>问题描述</th><th>当前节点</th><th>状态</th><th>负责人</th><th>最后更新</th></tr></thead><tbody>${tickets.map((ticket) => { const project = projectFor(ticket.projectId); const status = statusFor(ticket); return `<tr data-ticket="${ticket.id}"><td><strong>${ticket.id}</strong><div class="muted">${ticket.date || "—"}</div></td><td><strong>${escape(projectFor(ticket.projectId)?.contractNo || "待关联")}</strong></td><td>${escape(project?.name || "未关联项目")}</td><td><div class="cell-title">${escape(ticket.product || "未填写")}</div></td><td><div class="cell-title">${escape(ticket.description || "—")}</div></td><td>${escape(ticket.stage || "接收反馈")}</td><td><span class="status ${statusClass(status)}">${status}</span></td><td>${escape(ticket.owner || "未分配")}</td><td>${escape(ticket.lastUpdated || "—")}</td></tr>`; }).join("")}</tbody></table></div>`; }

function renderTickets() { return `${pageHeading("售后问题明细", "每个问题只录一次；配件、采购、照片和回访均关联售后编号。", `<button class="button primary" data-route="new-ticket">${icon("plus", "button-icon")}创建售后单</button>`)}
  <section class="panel"><div class="panel-head"><div class="toolbar" style="width:100%"><input class="field search" id="ticket-search" placeholder="搜索售后编号、项目、产品或问题" /><select class="select" id="ticket-status"><option value="">全部状态</option><option>待完成</option><option>处理中</option><option>已完成</option></select><select class="select" id="ticket-project"><option value="">全部项目</option>${data.projects.map((project) => `<option value="${project.id}">${escape(project.name)}</option>`).join("")}</select><span class="spacer"></span><span class="muted" id="ticket-count">共 ${data.tickets.length} 条</span></div></div><div id="ticket-table-area">${ticketTable(data.tickets)}</div></section>`; }
function filterTicketList() { const query = document.querySelector("#ticket-search")?.value.trim().toLowerCase() || ""; const status = document.querySelector("#ticket-status")?.value || ""; const projectId = document.querySelector("#ticket-project")?.value || ""; const filtered = data.tickets.filter((ticket) => { const project = projectFor(ticket.projectId); const haystack = [ticket.id, ticket.product, ticket.description, project?.name].join(" ").toLowerCase(); return (!query || haystack.includes(query)) && (!status || statusFor(ticket) === status) && (!projectId || ticket.projectId === projectId); }); document.querySelector("#ticket-table-area").innerHTML = ticketTable(filtered); document.querySelector("#ticket-count").textContent = `共 ${filtered.length} 条`; }

function renderNewTicket() {
  const online = newTicketMode === "online";
  return `${pageHeading("创建售后单", "支持在线填写，也可以直接导入现有维修表。")}
    <div class="tabs"><button class="tab ${online ? "active" : ""}" data-new-mode="online">在线填写</button><button class="tab ${online ? "" : "active"}" data-new-mode="import">导入表单</button></div>
    ${online ? renderOnlineForm() : renderImportForm()}`;
}
function renderOnlineForm() { return `<div class="form-layout"><form class="panel form-panel" id="new-ticket-form">
  <div class="form-section"><h3>问题基本信息</h3><div class="form-grid three">
    <div class="form-group"><label>售后编号</label><input id="new-ticket-code" value="选择项目后自动生成" readonly /></div>
    <div class="form-group"><label>反馈日期 *</label><input name="date" type="date" value="${today()}" required /></div>
    <div class="form-group"><label>项目编号（合同号） *</label><select name="projectId" required><option value="">请选择项目</option>${data.projects.map((project) => `<option value="${escape(project.id)}">${escape(project.contractNo)} · ${escape(project.name)}</option>`).join("")}</select></div>
    <div class="form-group wide"><label>关联实际交付产品（已有交付记录时选择）<select name="deliveryLineId"><option value="">未选择／历史项目待核对</option></select></label></div><div class="form-group"><label>产品名称 *</label><input name="product" placeholder="例如：灯带、蹦床区" required /></div>
    <div class="form-group"><label>产品名称（客户版英文）</label><input name="productEn" placeholder="例如：LED Strip" /></div>
    <div class="form-group"><label>问题分类 *</label><select name="category" required>${optionList(ISSUE_CATEGORIES)}</select></div>
    <div class="form-group"><label>售后负责人</label><input name="owner" placeholder="填写负责跟进人员" /></div>
    <div class="form-group wide"><label>问题描述 *</label><textarea name="description" placeholder="请写明位置、具体故障、客户反馈时间和影响情况" required></textarea></div>
    <div class="form-group wide"><label>问题描述（客户版英文）</label><textarea name="descriptionEn" placeholder="English customer-facing issue description"></textarea></div>
  </div></div>
  <div class="form-section"><h3>分析与处理</h3><div class="form-grid three">
    <div class="form-group"><label>原因分类</label><select name="causeCategory">${optionList(CAUSE_CATEGORIES)}</select></div>
    <div class="form-group"><label>处理方式</label><select name="handling">${optionList(HANDLING_METHODS)}</select></div>
    <div class="form-group"><label>当前节点 *</label><select name="stage" required>${optionList(STAGES, "接收反馈", "请选择节点")}</select></div>
    <div class="form-group"><label>预计完成日期</label><input name="dueDate" type="date" /></div>
    <div class="form-group"><label>是否重复发生</label><select name="repeated">${optionList(["否", "是"], "否", "请选择")}</select></div>
    <div class="form-group"><label>是否需要产品改善</label><select name="needsImprovement">${optionList(["否", "是"], "否", "请选择")}</select></div>
    <div class="form-group wide"><label>初步原因分析</label><textarea name="causeAnalysis" placeholder="暂未确认可先保留“待确认”"></textarea></div>
    <div class="form-group wide"><label>初步原因分析（客户版英文）</label><textarea name="causeAnalysisEn" placeholder="English inspection and analysis"></textarea></div>
    <div class="form-group wide"><label>解决方案 / 改善建议</label><textarea name="solution" placeholder="可先记录临时处理方案，后续在售后单详情持续更新"></textarea></div>
    <div class="form-group wide"><label>解决方案（客户版英文）</label><textarea name="solutionEn" placeholder="English recommended solution"></textarea></div>
  </div></div>
  <div class="form-section"><h3>现场照片与附件</h3><div class="dropzone"><label for="new-files">${icon("upload", "upload-icon")}<strong>选择照片或拖入文件</strong><span>照片独立保存在本机，不嵌入 Excel；支持多选。</span></label><input id="new-files" type="file" multiple accept="image/*,.pdf,.doc,.docx" /></div><div id="new-file-list" class="file-list"></div></div>
  <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:22px"><button type="button" class="button secondary" data-route="tickets">取消</button><button class="button primary" type="submit">创建售后单</button></div>
  </form><aside><div class="panel info-card"><h3>状态同步规则</h3><p>状态不需要手工选择，由“当前节点”自动显示：</p><ul><li>接收反馈、建立售后单 → 待完成</li><li>初步分析至售后回访 → 处理中</li><li>关闭与复盘 → 已完成</li></ul></div><div class="panel info-card"><h3>填写建议</h3><p>先记录客户反馈和照片，信息不完整时原因分类选择“待确认”。后续处理、回访、配件和采购在售后单详情中继续补充。</p></div></aside></div>`; }
function renderImportForm() { return `<div class="form-layout"><section class="panel form-panel"><div class="notice">${icon("upload", "notice-icon")}<div><strong>导入规则</strong><br/>一次可加入多份维修表和现场照片。Excel 内嵌图片会自动按明细行识别；只有点击“确认导入”后才会创建项目、售后单并上传照片。</div></div><div class="dropzone import-dropzone" id="import-dropzone" style="min-height:205px" aria-describedby="import-file-status"><label for="import-files" tabindex="0">${icon("upload", "upload-icon")}<strong>拖入 Excel 维修表和现场照片</strong><span>可一次拖入多个 .xlsx / .csv 文件及图片；也可点击选择。</span></label><input id="import-files" type="file" multiple accept=".xlsx,.csv,image/*" /></div><p id="import-file-status" class="dropzone-status" aria-live="polite">先加入文件，确认前不会上传任何资料</p><div id="import-review">${renderImportReview()}</div></section><aside><div class="panel info-card"><h3>照片如何关联</h3><p>Excel 内嵌照片会按所在明细行自动关联；额外拖入的照片可在确认前指定对应售后问题。</p></div><div class="panel info-card"><h3>导入不会覆盖数据</h3><p>系统会检查同一项目、日期和问题描述；重复问题不会重复建立，照片仍可关联到原有售后单。</p></div></aside></div>`; }
function importTargets() { return importQueue.workbooks.flatMap((item) => item.payload?.tickets.map((ticket, index) => ({ key: `${item.id}:${index}`, label: `${item.payload.project.name || "未命名项目"} · ${ticket.product || "未填写产品"} · ${ticket.description || "未填写问题"}` })) || []); }
function renderImportReview() {
  const workbooks = importQueue.workbooks;
  const photos = importQueue.photos;
  if (!workbooks.length && !photos.length) return `<div class="import-empty"><strong>尚未加入文件</strong><span>可把多份维修表和现场照片一起拖到上方区域。</span></div>`;
  const targets = importTargets();
  const invalidCount = workbooks.filter((item) => item.error).length;
  const workbookRows = workbooks.map((item) => `<div class="import-file-row"><div><strong>${escape(item.file.name)}</strong><span>${formatBytes(item.file.size)}${item.error ? ` · ${escape(item.error)}` : item.payload ? ` · 已识别 ${item.payload.tickets.length} 条问题` : " · 正在读取"}</span></div><button class="text-button" type="button" data-remove-import="workbook:${item.id}">移除</button></div>`).join("");
  const photoRows = photos.map((item) => `<div class="import-photo-row"><div><strong>${escape(item.file.name)}</strong><span>${formatBytes(item.file.size)}${item.source ? ` · ${escape(item.source)}` : ""}</span></div><select class="select" data-photo-target="${item.id}" ${targets.length ? "" : "disabled"}><option value="">选择对应售后问题</option>${targets.map((target) => `<option value="${escape(target.key)}" ${target.key === item.targetKey ? "selected" : ""}>${escape(target.label)}</option>`).join("")}</select><button class="text-button" type="button" data-remove-import="photo:${item.id}">移除</button></div>`).join("");
  const canConfirm = workbooks.length && !invalidCount && workbooks.every((item) => item.payload);
  return `<section class="import-review"><div class="import-review-head"><div><div class="panel-title">待确认导入</div><div class="panel-subtitle">已加入 ${workbooks.length} 份维修表、${photos.length} 张现场照片；确认前不会写入系统。</div></div><button class="button secondary small" type="button" id="clear-import-queue">清空</button></div>${workbooks.length ? `<div class="import-review-section"><h3>维修表</h3>${workbookRows}</div>` : ""}${photos.length ? `<div class="import-review-section"><h3>现场照片</h3>${targets.length ? "" : `<p class="import-hint">请先加入并读取维修表，再为照片选择对应的问题。</p>`}${photoRows}</div>` : ""}<div class="import-confirm-row"><span>${invalidCount ? "请移除无法识别的维修表后再确认。" : canConfirm ? "确认后将创建售后单，并把照片上传至对应记录。" : "正在读取维修表，请稍候。"}</span><button class="button primary" type="button" id="confirm-import" ${canConfirm ? "" : "disabled"}>确认导入</button></div><label>本批维修表所属项目<select id="import-target-project"><option value="">请核对并选择统一项目</option>${data.projects.map(p=>`<option value="${escape(p.id)}">${escape(p.contractNo)} · ${escape(p.name)}</option>`).join('')}</select></label><div id="import-result"></div></section>`;
}
function updateImportReview() { const review = document.querySelector("#import-review"); if (!review) return; review.innerHTML = renderImportReview(); const status = document.querySelector("#import-file-status"); if (status) status.textContent = importQueue.workbooks.length || importQueue.photos.length ? `已加入 ${importQueue.workbooks.length} 份维修表、${importQueue.photos.length} 张现场照片；请确认后导入。` : "先加入文件，确认前不会上传任何资料"; bindImportReview(); }

function renderTicketDetail() {
  const ticket = data.tickets.find((item) => item.id === currentTicketId);
  if (!ticket) return `${pageHeading("未找到售后单", "这条记录可能已被删除。", `<button class="button secondary" data-route="tickets">返回列表</button>`)}<section class="panel empty"><strong>记录不存在</strong></section>`;
  const project = projectFor(ticket.projectId); const status = statusFor(ticket);
  return `${pageHeading(ticket.id, `${project?.name || "未关联项目"} · ${ticket.product || "未填写产品"}`, `<div class="toolbar"><button class="button secondary" data-route="tickets">返回售后明细</button></div>`)}
  <div class="detail-layout"><div>
    <form class="panel form-panel" id="ticket-update-form"><div class="detail-header" style="padding:0 0 19px"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:14px"><div><div class="panel-title">${escape(ticket.description || "未填写问题描述")}</div><div class="detail-meta"><span>项目编号：${escape(projectFor(ticket.projectId)?.contractNo || "待关联")}</span><span>反馈日期：${escape(ticket.date || "—")}</span><span>来源：${escape(ticket.source || "在线填写")}</span></div></div><span class="status ${statusClass(status)}">${status}</span></div></div>
      <div class="form-section"><h3>当前工作流</h3><div class="form-grid three"><div class="form-group"><label>当前节点 *</label><select name="stage" required>${optionList(STAGES, ticket.stage, "请选择节点")}</select></div><div class="form-group"><label>售后负责人</label><input name="owner" value="${escape(ticket.owner)}" /></div><div class="form-group"><label>预计完成日期</label><input name="dueDate" type="date" value="${escape(ticket.dueDate)}" /></div><div class="form-group"><label>回访日期</label><input name="followUpDate" type="date" value="${escape(ticket.followUpDate)}" /></div><div class="form-group"><label>回访结果</label><select name="followUpResult">${optionList(["正常", "仍有问题", "再次维修"], ticket.followUpResult)}</select></div><div class="form-group"><label>处理方式</label><select name="handling">${optionList(HANDLING_METHODS, ticket.handling)}</select></div></div></div>
      <div class="form-section"><h3>问题分析与解决</h3><div class="form-grid"><div class="form-group"><label>问题分类</label><select name="category">${optionList(ISSUE_CATEGORIES, ticket.category)}</select></div><div class="form-group"><label>原因分类</label><select name="causeCategory">${optionList(CAUSE_CATEGORIES, ticket.causeCategory)}</select></div><div class="form-group"><label>是否重复发生</label><select name="repeated">${optionList(["否", "是"], ticket.repeated)}</select></div><div class="form-group"><label>是否需要产品改善</label><select name="needsImprovement">${optionList(["否", "是"], ticket.needsImprovement)}</select></div><div class="form-group wide"><label>产品名称</label><input name="product" value="${escape(ticket.product)}" /></div><div class="form-group wide"><label>产品名称（客户版英文）</label><input name="productEn" value="${escape(ticket.productEn || CUSTOMER_ENGLISH[ticket.product] || "")}" /></div><div class="form-group wide"><label>问题描述</label><textarea name="description">${escape(ticket.description)}</textarea></div><div class="form-group wide"><label>问题描述（客户版英文）</label><textarea name="descriptionEn">${escape(ticket.descriptionEn || CUSTOMER_ENGLISH[ticket.description] || "")}</textarea></div><div class="form-group wide"><label>原因分析</label><textarea name="causeAnalysis">${escape(ticket.causeAnalysis)}</textarea></div><div class="form-group wide"><label>原因分析（客户版英文）</label><textarea name="causeAnalysisEn">${escape(ticket.causeAnalysisEn || CUSTOMER_ENGLISH[ticket.causeAnalysis] || "")}</textarea></div><div class="form-group wide"><label>解决方案</label><textarea name="solution">${escape(ticket.solution)}</textarea></div><div class="form-group wide"><label>解决方案（客户版英文）</label><textarea name="solutionEn">${escape(ticket.solutionEn || CUSTOMER_ENGLISH[ticket.solution] || "")}</textarea></div><div class="form-group wide"><label>问题总结</label><textarea name="summary">${escape(ticket.summary)}</textarea></div><div class="form-group wide"><label>问题总结（客户版英文）</label><textarea name="summaryEn">${escape(ticket.summaryEn || CUSTOMER_ENGLISH[ticket.summary] || "")}</textarea></div><div class="form-group wide"><label>改善建议</label><textarea name="suggestion">${escape(ticket.suggestion)}</textarea></div></div></div>
      <div style="display:flex;justify-content:flex-end;margin-top:22px"><button class="button primary" type="submit">保存售后单</button></div>
    </form>
    <section class="panel" style="margin-top:18px"><div class="panel-head"><div><div class="panel-title">配件领用记录</div><div class="panel-subtitle">申请后占用库存，仓库确认出库后计入领用记录</div></div></div><div class="panel-body"><form class="toolbar" id="part-use-form"><select class="select" name="partId" ${data.parts.length ? "" : "disabled"}><option value="">选择配件</option>${data.parts.map((part) => `<option value="${part.id}">${escape(part.sku)} · ${escape(part.name)}（库存 ${part.stock}${escape(part.unit || "个")}）</option>`).join("")}</select><input class="field" style="width:92px" name="qty" type="number" min="1" placeholder="数量" ${data.parts.length ? "" : "disabled"}/><button class="button secondary small" ${data.parts.length ? "" : "disabled"}>申请领用</button><span class="spacer"></span><button type="button" class="button secondary small" data-route="procurements">新建采购</button></form>${partUseTable(ticket)}</div></section>
  </div>
  <aside><section class="panel info-card"><h3>现场照片与附件</h3><div id="photo-grid" class="photo-grid"><div class="muted">正在读取附件…</div></div><div class="dropzone" style="min-height:92px;margin-top:13px"><label for="detail-files">${icon("image", "upload-icon")}<strong>补充照片 / 附件</strong></label><input id="detail-files" type="file" multiple accept="image/*,.pdf,.doc,.docx" /></div></section><section class="panel info-card"><h3>工作流历史</h3><div class="timeline">${(ticket.history || []).slice().reverse().map((entry) => `<div class="timeline-entry"><strong>${escape(entry.action)}</strong>${escape(entry.at)}<br/>${escape(entry.note || "")}</div>`).join("") || "<div class='timeline-entry'><strong>创建售后单</strong>暂无操作记录</div>"}</div></section></aside>
  </div>`;
}
function reportValue(value) { return value ? escape(value) : "—"; }
function reportOption(label, active) { return `<span class="report-option"><i class="report-check ${active ? "active" : ""}"></i>${label}</span>`; }
function customerEnglish(value, supplied = "") { if (!value) return ""; return supplied || CUSTOMER_ENGLISH[value] || "English wording to be confirmed"; }
function bilingualValue(chinese, english) { return `<div class="report-bilingual"><span>${reportValue(chinese)}</span><span class="report-en">${reportValue(customerEnglish(chinese, english))}</span></div>`; }
function reportFileName(projects) { const labels = projects.slice(0, 3).map((project) => `${project.id}_${project.name || "未命名项目"}`.replace(/[\\/:*?"<>|]/g, "-")); const more = projects.length > 3 ? `_等${projects.length}个项目` : ""; return `${labels.join("__")}${more}_客户售后服务报告`; }
function projectClientStatus(tickets) { if (tickets.length && tickets.every((ticket) => ticket.stage === "关闭与复盘")) return "Completed 已完成"; if (tickets.some((ticket) => ticket.stage === "售后回访")) return "Pending Client Confirmation 待客户确认"; if (tickets.some((ticket) => ["更换配件", "补货", "重新生产"].includes(ticket.handling))) return "Parts in Preparation 配件准备中"; if (tickets.some((ticket) => ticket.stage === "执行处理")) return "Under Repair 维修中"; return "Pending 待处理"; }
function clientParts(tickets) { const uses = tickets.flatMap((ticket) => (ticket.partsUsed || []).map((item) => ({ ...item, ticketId: ticket.id }))); return uses.length ? uses.map((item, index) => `<tr><td>${index + 1}</td><td>${reportValue(item.name)}</td><td>${reportValue(item.sku)}</td><td>${reportValue(`${item.qty}${item.unit || "个"}`)}</td><td>${reportValue(item.note)}${item.ticketId ? ` · ${escape(item.ticketId)}` : ""}</td></tr>`).join("") : `<tr><td>1</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>2</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>3</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>`; }
function renderClientReport() {
  const projectIds = String(currentTicketId || "").split(",").filter(Boolean);
  const projects = projectIds.map((id) => data.projects.find((item) => item.id === id)).filter(Boolean);
  if (!projects.length) return `${pageHeading("未找到项目", "该项目可能已被删除。", `<button class="button secondary" data-route="customer-reports">返回客户售后服务表单</button>`)}<section class="panel empty"><strong>项目不存在</strong></section>`;
  document.title = reportFileName(projects);
  const label = projects.length > 1 ? `已选择 ${projects.length} 个项目` : "项目客户服务报告";
  return `<div class="client-report-toolbar"><span class="report-selection-note">${label}</span><span class="spacer"></span><button class="button secondary" data-client-report-back>返回项目档案</button><button class="button primary" id="print-client-report">打印 / 导出 PDF</button></div><div class="client-report-batch">${projects.map((project) => renderProjectClientReport(project)).join("")}</div>`;
}
function renderProjectClientReport(project) {
  const tickets = data.tickets.filter((ticket) => ticket.projectId === project.id);
  const latestDate = tickets.map((ticket) => ticket.lastUpdated || ticket.date).filter(Boolean).sort().at(-1) || today();
  const completedCount = tickets.filter((ticket) => ticket.stage === "关闭与复盘").length;
  const activeCount = tickets.filter((ticket) => ticket.stage === "执行处理" || ticket.stage === "售后回访").length;
  const pendingCount = tickets.length - completedCount - activeCount;
  const actions = tickets.map((ticket) => ticket.handling).filter(Boolean);
  const hasAction = (action) => actions.includes(action);
  return `<article class="client-report">
    <header class="client-report-header"><img src="./assets/yifun-life-logo-transparent.png" width="1431" height="340" alt="YIFUN LIFE"><div><h1>AFTER-SALES SERVICE REPORT</h1><p>客户售后服务报告</p></div></header>
    <div class="client-report-meta"><span><b>Project No. 项目编号：</b>${reportValue(project.id)}</span><span><b>Date 日期：</b>${reportValue(latestDate)}</span></div>
    <section class="report-section"><h2>1. 项目信息 <small>/ Project Information</small></h2><table class="report-kv"><tbody><tr><th>客户名称 / Client</th><td>${reportValue(project.client)}</td><th>项目名称 / Project</th><td>${bilingualValue(project.name, project.nameEn)}</td></tr><tr><th>项目编号 / Project No.</th><td>${reportValue(project.id)}</td><th>国家 / Country</th><td>${bilingualValue(project.country, CUSTOMER_ENGLISH[project.country])}</td></tr><tr><th>联系人 / Contact Person</th><td colspan="3">${reportValue(project.contact)}${project.phone ? ` · ${escape(project.phone)}` : ""}</td></tr></tbody></table></section>
    <section class="report-section"><h2>2. 产品信息 <small>/ Product Information</small></h2><table class="report-table"><thead><tr><th>产品名称（中文）</th><th>Product Name (English)</th><th>产品编号 / SKU</th><th>数量 / Qty</th><th>安装位置 / Location</th></tr></thead><tbody>${tickets.length ? tickets.map((ticket) => `<tr><td>${reportValue(ticket.product)}</td><td>${reportValue(customerEnglish(ticket.product, ticket.productEn))}</td><td>—</td><td>—</td><td>—</td></tr>`).join("") : `<tr><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>`}</tbody></table></section>
    <section class="report-section"><h2>3. 问题描述 <small>/ Issue Description</small></h2><table class="report-table"><thead><tr><th>售后单号 / Service No.</th><th>问题描述（中文）</th><th>Issue Description (English)</th><th>状态 / Status</th></tr></thead><tbody>${tickets.length ? tickets.map((ticket) => `<tr><td>${escape(ticket.id)}</td><td>${reportValue(ticket.description)}</td><td>${reportValue(customerEnglish(ticket.description, ticket.descriptionEn))}</td><td>${bilingualValue(statusFor(ticket), CUSTOMER_ENGLISH[statusFor(ticket)])}</td></tr>`).join("") : `<tr><td colspan="4">暂无售后记录 / No service records</td></tr>`}</tbody></table><div class="report-copy"><b>问题照片 / Issue Photos：</b><div class="report-photo-grid" data-client-report-photos="${escape(project.id)}"><span class="report-muted">正在读取现场照片…</span></div></div></section>
    <section class="report-section"><h2>4. 问题分析 <small>/ Issue Analysis</small></h2><table class="report-table"><thead><tr><th>售后单号 / Service No.</th><th>问题分析（中文）</th><th>Inspection &amp; Analysis (English)</th></tr></thead><tbody>${tickets.length ? tickets.map((ticket) => { const analysis = ticket.causeAnalysis === "待确认" ? "待进一步检查确认" : ticket.causeAnalysis; return `<tr><td>${escape(ticket.id)}</td><td>${reportValue(analysis)}</td><td>${reportValue(customerEnglish(analysis, ticket.causeAnalysisEn))}</td></tr>`; }).join("") : `<tr><td colspan="3">—</td></tr>`}</tbody></table></section>
    <section class="report-section"><h2>5. 解决方案 <small>/ Solution</small></h2><table class="report-table"><thead><tr><th>售后单号 / Service No.</th><th>解决方案（中文）</th><th>Recommended Solution (English)</th><th>处理方式 / Service Action</th></tr></thead><tbody>${tickets.length ? tickets.map((ticket) => `<tr><td>${escape(ticket.id)}</td><td>${reportValue(ticket.solution)}</td><td>${reportValue(customerEnglish(ticket.solution, ticket.solutionEn))}</td><td>${bilingualValue(ticket.handling, CUSTOMER_ENGLISH[ticket.handling])}</td></tr>`).join("") : `<tr><td colspan="4">—</td></tr>`}</tbody></table></section>
    <section class="report-section"><h2>6. 所需配件 <small>/ Required Parts</small></h2><table class="report-table"><thead><tr><th>No.</th><th>配件名称 / Part</th><th>Part No. / SKU</th><th>Qty / 数量</th><th>Remark / 备注</th></tr></thead><tbody>${clientParts(tickets)}</tbody></table></section>
    <section class="report-section report-actions"><h2>7. 双方行动 <small>/ Action Required</small></h2><div><b>YIFUN Action / 我方处理：</b><div class="report-options">${reportOption("提供维修指导 / Provide repair instructions", hasAction("远程指导") || hasAction("维修"))}${reportOption("提供视频 / Provide instruction video", false)}${reportOption("补发配件 / Send replacement parts", hasAction("更换配件") || hasAction("补货"))}${reportOption("重新生产 / Reproduce parts", hasAction("重新生产"))}${reportOption("其他 / Other", hasAction("其他"))}</div></div><div><b>Customer Action / 客户配合：</b><div class="report-options">${reportOption("按指导检查设备 / Inspect equipment as instructed", tickets.length > 0)}${reportOption("更换配件 / Replace parts", hasAction("更换配件"))}${reportOption("提供照片或视频 / Provide photos or videos", false)}${reportOption("完成后确认设备状态 / Confirm equipment condition after repair", tickets.length > 0)}</div></div></section>
    <section class="report-section"><h2>8. 处理结果 <small>/ Service Result</small></h2><div class="report-options status-options">${["Pending 待处理", "Parts in Preparation 配件准备中", "Parts Shipped 配件已发出", "Under Repair 维修中", "Completed 已完成", "Pending Client Confirmation 待客户确认"].map((item) => reportOption(item, item === projectClientStatus(tickets))).join("")}</div><div class="report-copy"><b>Result / 处理结果：</b><p>本项目共 ${tickets.length} 条售后事项；已完成 ${completedCount} 条，处理中 ${activeCount} 条，待处理 ${pendingCount} 条。<br/><span class="report-en">This project has ${tickets.length} service items: ${completedCount} completed, ${activeCount} in progress, and ${pendingCount} pending.</span></p></div></section>
    <section class="report-section client-confirmation"><h2>9. 客户确认 <small>/ Client Confirmation</small></h2><div class="report-copy"><b>Is the issue resolved? / 问题是否已解决？</b><div class="report-options">${reportOption("Yes 是", false)}${reportOption("No 否", false)}${reportOption("Further Support Required 需要继续处理", false)}</div></div><div class="report-copy"><b>Client Comments / 客户意见：</b><p class="report-blank"></p></div><div class="signature-grid"><span>Client Name / 客户姓名：________________</span><span>Signature / 签名：________________</span><span>Date / 日期：________________</span></div></section>
  </article>`;
}
async function loadClientReportPhotos(projectIds) { const selected = String(projectIds || "").split(",").filter(Boolean); await Promise.all(selected.map(async (projectId) => { const container = document.querySelector(`[data-client-report-photos="${CSS.escape(projectId)}"]`); if (!container) return; try { const tickets = data.tickets.filter((ticket) => ticket.projectId === projectId); const groups = await Promise.all(tickets.map(async (ticket) => ({ ticket, photos: await photoStore.list(ticket.id) }))); const images = groups.flatMap(({ ticket, photos }) => photos.filter((photo) => photo.type.startsWith("image/")).map((photo) => ({ ...photo, ticketId: ticket.id }))); container.innerHTML = images.length ? images.map((photo) => `<figure><img src="${photo.url}" alt="${escape(photo.name)}"><figcaption>${escape(photo.ticketId)} · ${escape(photo.name)}</figcaption></figure>`).join("") : `<span class="report-muted">暂无现场照片</span>`; } catch { container.innerHTML = `<span class="report-muted">现场照片暂不可读取</span>`; } })); }
function partUseTable(ticket) { const uses = ticket.partsUsed || []; if (!uses.length) return `<div class="empty" style="padding:24px 0 5px"><strong style="font-size:13px">暂无配件领用</strong><p>配件使用后可在这里登记。</p></div>`; return `<div class="table-wrap" style="margin-top:15px"><table class="data-table" style="min-width:600px"><thead><tr><th>配件</th><th>数量</th><th>登记日期</th><th>备注</th></tr></thead><tbody>${uses.map((use) => `<tr><td>${escape(use.sku)} · ${escape(use.name)}</td><td>${use.qty}${escape(use.unit || "个")}</td><td>${escape(use.date)}</td><td>${escape(use.note || "—")}</td></tr>`).join("")}</tbody></table></div>`; }

function renderParts() { return `${pageHeading("配件管理", "维护常用维修配件库存；领用记录会自动关联售后编号。", `<button class="button primary" id="show-part-form">${icon("plus", "button-icon")}常用配件设置</button>`)}
  <section class="panel" id="part-create-area"></section><section class="panel" style="margin-top:18px"><div class="panel-head"><div><div class="panel-title">配件库存</div><div class="panel-subtitle">低于安全库存的配件会标记为需关注</div></div></div>${partsTable()}</section>`; }
function partsTable() { if (!data.parts.length) return `<div class="empty"><strong>还没有配件资料</strong><p>先新增常用配件，后续即可从售后单登记领用并扣减库存。</p></div>`; return `<div class="table-wrap"><table class="data-table"><thead><tr><th>配件编号</th><th>配件名称</th><th>类别</th><th>关联产品</th><th>当前库存</th><th>安全库存</th><th>状态</th></tr></thead><tbody>${data.parts.map((part) => { const low = Number(part.stock) <= Number(part.minStock || 0); return `<tr><td><strong>${escape(part.sku)}</strong></td><td>${escape(part.name)}</td><td>${escape(part.category || "—")}</td><td>${escape(part.product || "—")}</td><td>${part.stock}${escape(part.unit || "个")}</td><td>${part.minStock || 0}${escape(part.unit || "个")}</td><td><span class="status ${low ? "overdue" : "done"}">${low ? "需补货" : "库存正常"}</span></td></tr>`; }).join("")}</tbody></table></div>`; }
function partForm() { return `<div class="form-panel"><div class="panel-title" style="margin-bottom:16px">新增配件</div><form id="new-part-form" class="form-grid three"><div class="form-group"><label>配件编号 *</label><input name="sku" value="${nextCode("PT", data.parts)}" required/></div><div class="form-group"><label>配件名称 *</label><input name="name" required/></div><div class="form-group"><label>配件类别</label><input name="category" placeholder="例如：电器、五金"/></div><div class="form-group"><label>关联产品</label><input name="product" placeholder="例如：互动球机"/></div><div class="form-group"><label>当前库存 *</label><input name="stock" type="number" min="0" value="0" required/></div><div class="form-group"><label>安全库存</label><input name="minStock" type="number" min="0" value="0"/></div><div class="form-group"><label>单位</label><input name="unit" value="个"/></div><div class="form-group wide"><label>备注</label><input name="notes"/></div><div class="form-group wide" style="display:flex;flex-direction:row;justify-content:flex-end"><button type="button" class="button secondary" id="cancel-part-form">取消</button><button class="button primary">保存配件</button></div></form></div>`; }

function renderProcurements() { return `${pageHeading("采购信息", "补件、采购或重新生产可关联售后编号，让处理进度可追溯。", `<button class="button primary" id="show-procurement-form">${icon("plus", "button-icon")}新建采购记录</button>`)}
  <section class="panel" id="procurement-create-area"></section><section class="panel" style="margin-top:18px"><div class="panel-head"><div><div class="panel-title">采购记录</div><div class="panel-subtitle">采购状态可直接更新，售后编号用于反查来源问题</div></div></div>${procurementsTable()}</section>`; }
function procurementsTable() { if (!data.procurements.length) return `<div class="empty"><strong>暂时没有采购记录</strong><p>需要补件、采购或重新生产时在这里建立记录。</p></div>`; return `<div class="table-wrap"><table class="data-table"><thead><tr><th>采购编号</th><th>关联售后单</th><th>配件 / 物料</th><th>数量</th><th>供应商</th><th>预计到货</th><th>采购状态</th></tr></thead><tbody>${data.procurements.map((item) => `<tr data-procurement="${item.id}"><td><strong>${escape(item.id)}</strong><div class="muted">${escape(item.orderDate || "—")}</div></td><td>${item.ticketId ? `<button class="button secondary small" data-ticket="${item.ticketId}">${escape(item.ticketId)}</button>` : "—"}</td><td>${escape(item.partName)}</td><td>${item.qty}${escape(item.unit || "个")}</td><td>${escape(item.supplier || "待确认")}</td><td>${escape(item.expectedDate || "—")}</td><td><select class="select procurement-status" data-procurement-status="${item.id}">${optionList(PROCUREMENT_STATUSES, item.status, "请选择状态")}</select></td></tr>`).join("")}</tbody></table></div>`; }
function procurementForm() { return `<div class="form-panel"><div class="panel-title" style="margin-bottom:16px">新建采购记录</div><form id="new-procurement-form" class="form-grid three"><div class="form-group"><label>采购编号</label><input value="${nextCode("PO", data.procurements)}" readonly /></div><div class="form-group"><label>关联售后单</label><select name="ticketId">${optionList(data.tickets.map((ticket) => ticket.id))}</select></div><div class="form-group"><label>配件 / 物料 *</label><input name="partName" list="part-names" required/><datalist id="part-names">${data.parts.map((part) => `<option value="${escape(part.name)}"></option>`).join("")}</datalist></div><div class="form-group"><label>数量 *</label><input name="qty" type="number" min="1" required/></div><div class="form-group"><label>单位</label><input name="unit" value="个"/></div><div class="form-group"><label>供应商</label><input name="supplier" /></div><div class="form-group"><label>采购日期</label><input name="orderDate" type="date" value="${today()}"/></div><div class="form-group"><label>预计到货日期</label><input name="expectedDate" type="date"/></div><div class="form-group"><label>采购状态</label><select name="status">${optionList(PROCUREMENT_STATUSES, "待采购", "请选择")}</select></div><div class="form-group wide"><label>备注</label><input name="notes"/></div><div class="form-group wide" style="display:flex;flex-direction:row;justify-content:flex-end"><button type="button" class="button secondary" id="cancel-procurement-form">取消</button><button class="button primary">保存采购记录</button></div></form></div>`; }

function renderProjects() { return `${pageHeading("项目档案", "项目档案来自 Workplace；售后单按固定项目编号关联。", `<div class="toolbar"><button class="button secondary" id="export-backup">导出售后资料副本</button><button class="button primary" id="export-selected-reports" disabled>批量导出 PDF</button></div>`)}
  <section class="panel"><div class="panel-head"><div><div class="panel-title">已建项目</div><div class="panel-subtitle">勾选项目后可一次生成多份客户服务报告并导出为一个 PDF</div></div><span class="selection-count" id="project-selection-count">已选择 0 个项目</span></div>${projectsTable()}</section>`; }
function renderCustomerReports() { return `${pageHeading("客户售后服务表单", "选择一个或多个项目，自动汇总该项目下的售后记录、配件和现场照片。", `<button class="button primary" id="export-selected-reports" disabled>批量导出 PDF</button>`)}
  <section class="panel"><div class="panel-head"><div><div class="panel-title">选择项目</div><div class="panel-subtitle">单个项目可打开报告；多选项目可合并导出为一个多页 PDF</div></div><span class="selection-count" id="project-selection-count">已选择 0 个项目</span></div>${projectsTable()}</section>`; }
function projectsTable() { const allSelected = data.projects.length > 0 && data.projects.every((project) => selectedProjectIds.has(project.id)); return `<div class="table-wrap"><table class="data-table"><thead><tr><th class="select-column"><input type="checkbox" id="select-all-projects" aria-label="选择全部项目" ${allSelected ? "checked" : ""}></th><th>项目编号（合同号）</th><th>项目名称</th><th>联系人</th><th>项目地址</th><th>跟进人</th><th>关联售后单</th><th>客户服务报告</th></tr></thead><tbody>${data.projects.map((project) => `<tr><td class="select-column"><input type="checkbox" class="project-report-select" value="${escape(project.id)}" aria-label="选择项目 ${escape(project.id)}" ${selectedProjectIds.has(project.id) ? "checked" : ""}></td><td><button class="button secondary small" data-client-report="${escape(project.id)}">${escape(project.contractNo)}</button></td><td>${escape(project.name)}</td><td>${escape(project.contact || "—")}<div class="muted">${escape(project.phone || "")}</div></td><td><div class="cell-title">${escape(project.address || "—")}</div></td><td>${escape(project.owner || "—")}</td><td>${data.tickets.filter((ticket) => ticket.projectId === project.id).length}</td><td><button class="button primary small" data-client-report="${escape(project.id)}">打开报告</button></td></tr>`).join("")}</tbody></table></div>`; }

function openClientReport(projectIds) { const ids = String(projectIds || "").split(",").filter(Boolean); const missing = data.tickets.filter((ticket) => ids.includes(ticket.projectId)).flatMap((ticket) => ["product", "description", "causeAnalysis", "solution", "summary"].filter((field) => ticket[field] && !ticket[`${field}En`] && !CUSTOMER_ENGLISH[ticket[field]]).map(() => ticket.id)); if (missing.length) return toast(`请先补充 ${[...new Set(missing)].join("、")} 的客户版英文内容`); setRoute("client-report", ids.join(",")); }
function bindRoute() {
  document.querySelectorAll("[data-route]").forEach((button) => button.addEventListener("click", () => setRoute(button.dataset.route)));
  document.querySelectorAll("[data-ticket]").forEach((node) => node.addEventListener("click", (event) => { event.stopPropagation(); setRoute("ticket-detail", node.dataset.ticket); }));
  document.querySelectorAll("[data-client-report]").forEach((button) => button.addEventListener("click", () => openClientReport(button.dataset.clientReport)));
  document.querySelectorAll("[data-client-report-back]").forEach((button) => button.addEventListener("click", () => setRoute("customer-reports")));
  if (route === "tickets") {
    ["#ticket-search", "#ticket-status", "#ticket-project"].forEach((selector) => document.querySelector(selector)?.addEventListener("input", filterTicketList));
    document.querySelector("#ticket-status")?.addEventListener("change", filterTicketList); document.querySelector("#ticket-project")?.addEventListener("change", filterTicketList);
  }
  if (route === "new-ticket") bindNewTicket();
  if (route === "ticket-detail") bindTicketDetail();
  if (route === "client-report") { loadClientReportPhotos(currentTicketId); document.querySelector("#print-client-report")?.addEventListener("click", () => window.print()); }
  if (route === "parts") bindParts();
  if (route === "procurements") bindProcurements();
  if (route === "projects" || route === "customer-reports") bindProjectReports();
}
function bindProjectReports() {
  const refreshSelection = () => {
    const count = selectedProjectIds.size;
    document.querySelector("#project-selection-count").textContent = `已选择 ${count} 个项目`;
    document.querySelector("#export-selected-reports").disabled = count === 0;
    const selectAll = document.querySelector("#select-all-projects");
    if (selectAll) { selectAll.checked = data.projects.length > 0 && data.projects.every((project) => selectedProjectIds.has(project.id)); selectAll.indeterminate = count > 0 && !selectAll.checked; }
  };
  document.querySelector("#export-backup")?.addEventListener("click", exportBackup);
  document.querySelectorAll(".project-report-select").forEach((checkbox) => checkbox.addEventListener("change", () => { if (checkbox.checked) selectedProjectIds.add(checkbox.value); else selectedProjectIds.delete(checkbox.value); refreshSelection(); }));
  document.querySelector("#select-all-projects")?.addEventListener("change", (event) => { if (event.target.checked) data.projects.forEach((project) => selectedProjectIds.add(project.id)); else selectedProjectIds.clear(); document.querySelectorAll(".project-report-select").forEach((checkbox) => { checkbox.checked = event.target.checked; }); refreshSelection(); });
  document.querySelector("#export-selected-reports")?.addEventListener("click", () => { if (!selectedProjectIds.size) return toast("请先选择项目"); openClientReport([...selectedProjectIds].join(",")); });
  refreshSelection();
}
function bindNewTicket() {
  document.querySelectorAll("[data-new-mode]").forEach((button) => button.addEventListener("click", () => { newTicketMode = button.dataset.newMode; pendingFiles = []; render(); }));
  const fileInput = document.querySelector("#new-files");
  fileInput?.addEventListener("change", () => { pendingFiles = [...fileInput.files]; renderPendingFiles(); });
  const projectSelect = document.querySelector("#new-ticket-form [name=\"projectId\"]");
  projectSelect?.addEventListener("change", () => {
    const code = document.querySelector("#new-ticket-code");
    if (code) code.value = projectSelect.value ? nextTicketCode(projectSelect.value) : "选择项目后自动生成";
    const delivery=document.querySelector('[name="deliveryLineId"]');if(delivery)delivery.innerHTML='<option value="">未选择／历史项目待核对</option>'+data.deliveries.filter(d=>d.project_id===projectSelect.value).map(d=>`<option value="${escape(d.id)}">${escape(d.number)} · ${escape(d.name_snapshot)} · ${escape(d.model_snapshot)} × ${d.quantity}</option>`).join('');
  });
  document.querySelector("#new-ticket-form")?.addEventListener("submit", createTicket);
  const importInput = document.querySelector("#import-files");
  const importDropzone = document.querySelector("#import-dropzone");
  const importLabel = importDropzone?.querySelector("label");
  importInput?.addEventListener("change", (event) => { addImportFiles(event.target.files); event.target.value = ""; });
  importLabel?.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); importInput?.click(); } });
  if (importDropzone) {
    ["dragenter", "dragover"].forEach((type) => importDropzone.addEventListener(type, (event) => { event.preventDefault(); importDropzone.classList.add("is-dragging"); }));
    ["dragleave", "dragend"].forEach((type) => importDropzone.addEventListener(type, (event) => { event.preventDefault(); importDropzone.classList.remove("is-dragging"); }));
    importDropzone.addEventListener("drop", (event) => { event.preventDefault(); importDropzone.classList.remove("is-dragging"); addImportFiles(event.dataTransfer?.files || []); });
  }
  bindImportReview();
}
function isWorkbook(file) { return /\.(xlsx|csv)$/i.test(file.name); }
function isPhoto(file) { return file.type.startsWith("image/"); }
function addImportFiles(files) {
  const rejected = [];
  for (const file of files) {
    if (isWorkbook(file)) {
      if (!importQueue.workbooks.some((item) => item.file.name === file.name && item.file.size === file.size && item.file.lastModified === file.lastModified)) importQueue.workbooks.push({ id: uid("workbook"), file, payload: null, error: "", reading: false });
    } else if (isPhoto(file)) {
      if (!importQueue.photos.some((item) => item.file.name === file.name && item.file.size === file.size && item.file.lastModified === file.lastModified)) importQueue.photos.push({ id: uid("photo"), file, targetKey: "" });
    } else rejected.push(file.name);
  }
  if (rejected.length) toast(`未加入 ${rejected.length} 个不支持的文件`);
  prepareImportQueue();
}
async function prepareImportQueue() {
  const unread = importQueue.workbooks.filter((item) => !item.payload && !item.error && !item.reading);
  unread.forEach((item) => { item.reading = true; });
  updateImportReview();
  await Promise.all(unread.map(async (item) => {
    try { item.payload = item.file.name.toLowerCase().endsWith(".csv") ? await parseCsv(item.file) : await parseXlsx(item.file); for (const photo of item.payload.embeddedPhotos || []) importQueue.photos.push({ id: uid("embedded-photo"), file: photo.file, targetKey: photo.ticketIndex >= 0 ? `${item.id}:${photo.ticketIndex}` : "", source: photo.source || "Excel 内嵌照片" }); }
    catch (error) { item.error = error.message || "无法读取此维修表"; }
    finally { item.reading = false; }
  }));
  const targets = importTargets();
  if (targets.length === 1) importQueue.photos.forEach((item) => { if (!item.targetKey) item.targetKey = targets[0].key; });
  updateImportReview();
}
function bindImportReview() {
  document.querySelector("#clear-import-queue")?.addEventListener("click", () => { importQueue = { workbooks: [], photos: [] }; updateImportReview(); });
  document.querySelectorAll("[data-remove-import]").forEach((button) => button.addEventListener("click", () => { const [kind, id] = button.dataset.removeImport.split(":"); importQueue[kind === "workbook" ? "workbooks" : "photos"] = importQueue[kind === "workbook" ? "workbooks" : "photos"].filter((item) => item.id !== id); if (kind === "workbook") { const targets = new Set(importTargets().map((item) => item.key)); importQueue.photos.forEach((item) => { if (!targets.has(item.targetKey)) item.targetKey = ""; }); } updateImportReview(); }));
  document.querySelectorAll("[data-photo-target]").forEach((select) => select.addEventListener("change", () => { const photo = importQueue.photos.find((item) => item.id === select.dataset.photoTarget); if (photo) photo.targetKey = select.value; }));
  document.querySelector("#confirm-import")?.addEventListener("click", confirmImportQueue);
}
function renderPendingFiles() { const container = document.querySelector("#new-file-list"); if (!container) return; container.innerHTML = pendingFiles.map((file, index) => `<div class="file-chip"><span>${escape(file.name)} <small>(${formatBytes(file.size)})</small></span><button type="button" data-remove-pending="${index}">移除</button></div>`).join(""); container.querySelectorAll("[data-remove-pending]").forEach((button) => button.addEventListener("click", () => { pendingFiles.splice(Number(button.dataset.removePending), 1); renderPendingFiles(); })); }
async function createTicket(event) { event.preventDefault(); const form = new FormData(event.currentTarget); const projectId = form.get("projectId"); const ticket = { id: nextTicketCode(projectId), projectId, deliveryLineId: form.get("deliveryLineId") || null, date: form.get("date"), product: form.get("product").trim(), productEn: form.get("productEn").trim(), description: form.get("description").trim(), descriptionEn: form.get("descriptionEn").trim(), category: form.get("category"), causeAnalysis: form.get("causeAnalysis").trim() || "待确认", causeAnalysisEn: form.get("causeAnalysisEn").trim(), causeCategory: form.get("causeCategory") || "待确认", solution: form.get("solution").trim(), solutionEn: form.get("solutionEn").trim(), handling: form.get("handling"), followUpDate: "", followUpResult: "", summary: "", summaryEn: "", repeated: form.get("repeated") || "否", needsImprovement: form.get("needsImprovement") || "否", suggestion: "", owner: form.get("owner").trim(), stage: form.get("stage"), dueDate: form.get("dueDate"), lastUpdated: today(), source: "在线填写", notes: "", partsUsed: [], history: [{ at: now(), action: "创建售后单", note: "在线填写" }] }; data.tickets.unshift(ticket); await saveData(); let uploadFailed = false; for (const file of pendingFiles) try { await photoStore.add(ticket.id, file); } catch { uploadFailed = true; } pendingFiles = []; toast(uploadFailed ? "售后单已创建；附件等待连接云端存储后上传" : "售后单已创建"); setRoute("ticket-detail", ticket.id); }

function bindTicketDetail() {
  const ticket = data.tickets.find((item) => item.id === currentTicketId); if (!ticket) return;
  loadPhotos(ticket.id);
  document.querySelector("#ticket-update-form")?.addEventListener("submit", (event) => updateTicket(event, ticket.id));
  document.querySelector("#detail-files")?.addEventListener("change", async (event) => { try { for (const file of event.target.files) await photoStore.add(ticket.id, file); ticket.history.push({ at: now(), action: "补充现场附件", note: `新增 ${event.target.files.length} 个文件` }); ticket.lastUpdated = today(); await saveData(); await loadPhotos(ticket.id); toast("附件已上传至云端存储"); } catch { toast("云端附件存储尚未连接，文件未保存在本机"); } });
  document.querySelector("#part-use-form")?.addEventListener("submit", (event) => usePart(event, ticket.id));
}
async function updateTicket(event, ticketId) { event.preventDefault(); const ticket = data.tickets.find((item) => item.id === ticketId); const form = new FormData(event.currentTarget); const previousStage = ticket.stage; ["stage", "owner", "dueDate", "followUpDate", "followUpResult", "handling", "category", "causeCategory", "repeated", "needsImprovement", "product", "productEn", "description", "descriptionEn", "causeAnalysis", "causeAnalysisEn", "solution", "solutionEn", "summary", "summaryEn", "suggestion"].forEach((key) => { ticket[key] = String(form.get(key) || "").trim(); }); ticket.lastUpdated = today(); if (previousStage !== ticket.stage) ticket.history.push({ at: now(), action: `工作节点更新为「${ticket.stage}」`, note: `状态自动同步为「${statusFor(ticket)}」` }); else ticket.history.push({ at: now(), action: "更新售后单", note: "补充处理、回访或分析信息" }); await saveData(); toast(`已保存，当前状态：${statusFor(ticket)}`); render(); }
async function loadPhotos(ticketId) { const container = document.querySelector("#photo-grid"); if (!container) return; try { const photos = await photoStore.list(ticketId); container.innerHTML = photos.length ? photos.map((photo) => { const source = photo.type.startsWith("image/") ? photo.url : ""; return `<div class="photo">${source ? `<img src="${source}" alt="${escape(photo.name)}"/>` : `<div class="file-fallback">${escape(photo.name)}</div>`}<button type="button" data-delete-photo="${photo.id}" aria-label="删除附件">×</button></div>`; }).join("") : `<div class="muted" style="grid-column:1/-1;font-size:12px">${cloudConfig.enabled ? "暂无附件" : "连接 Cloudflare R2 后可上传附件；文件不会保存在本机"}</div>`; container.querySelectorAll("[data-delete-photo]").forEach((button) => button.addEventListener("click", async () => { await photoStore.remove(button.dataset.deletePhoto); const ticket = data.tickets.find((item) => item.id === ticketId); ticket.history.push({ at: now(), action: "删除现场附件", note: "已移出附件列表，保留操作记录" }); await saveData(); loadPhotos(ticketId); toast("附件已删除"); })); } catch { container.innerHTML = `<div class="muted">云端附件存储暂不可用</div>`; } }
async function usePart(event,ticketId){event.preventDefault();const f=new FormData(event.currentTarget);await requestAction('stock-reserve',{purpose:'service',ticket_id:ticketId,product_id:f.get('partId'),quantity:Number(f.get('qty'))});toast('领用申请已提交，库存已占用，等待仓库出库');await loadCloudData();}

function bindParts() { document.querySelector("#show-part-form")?.addEventListener("click", () => { document.querySelector("#part-create-area").innerHTML = partForm(); bindPartForm(); }); }
function bindPartForm(){document.querySelector('#part-create-area').innerHTML=`<form id="new-part-form" class="form-grid"><label>共用产品<select name="productId" required>${data.parts.map(p=>`<option value="${escape(p.id)}">${escape(p.sku)} · ${escape(p.name)}</option>`).join('')}</select></label><label>最低库存<input name="minStock" type="number" min="0" value="0" required></label><label>备注<input name="notes"></label><button class="button primary">保存常用配件设置</button><p>产品由总入口维护，库存由采购入库形成。</p></form>`;document.querySelector('#new-part-form').addEventListener('submit',async event=>{event.preventDefault();const f=new FormData(event.currentTarget);await requestAction('service-part',{product_id:f.get('productId'),min_stock:Number(f.get('minStock')),notes:f.get('notes')});await loadCloudData();toast('配件设置已保存');});}
function bindProcurements(){document.querySelector('#show-procurement-form')?.addEventListener('click',bindProcurementForm);document.querySelectorAll('[data-procurement-status]').forEach(e=>{e.disabled=true;});}
function bindProcurementForm(){document.querySelector('#procurement-create-area').innerHTML=`<form id="new-procurement-form" class="form-grid"><label>售后单<select name="ticketId" required>${data.tickets.map(t=>`<option value="${escape(t.id)}">${escape(t.id)} · ${escape(t.product)}</option>`).join('')}</select></label><label>共用配件<select name="productId" required>${data.parts.map(p=>`<option value="${escape(p.id)}">${escape(p.sku)} · ${escape(p.name)}</option>`).join('')}</select></label><label>数量<input name="quantity" type="number" min="1" required></label><label>采购原因<input name="note" required></label><button class="button primary">提交采购申请</button></form>`;document.querySelector('#new-procurement-form').addEventListener('submit',async event=>{event.preventDefault();const f=new FormData(event.currentTarget);await requestAction('service-request',{ticket_id:f.get('ticketId'),product_id:f.get('productId'),quantity:Number(f.get('quantity')),note:f.get('note')});await loadCloudData();toast('已提交给采购，后续状态由采购流程更新');});}

async function confirmImportQueue() {
  const result = document.querySelector("#import-result");
  const unassigned = importQueue.photos.filter((item) => !item.targetKey);
  if (unassigned.length) return toast(`请为 ${unassigned.length} 张照片选择对应的售后问题`);
  const batches = importQueue.workbooks.filter((item) => item.payload && !item.error);
  if (!batches.length) return toast("请先加入可识别的维修表");
  const confirmButton = document.querySelector("#confirm-import");
  if (confirmButton) { confirmButton.disabled = true; confirmButton.textContent = "正在导入…"; }
  result.innerHTML = `<div class="notice">正在创建售后单并上传现场照片，请勿关闭页面…</div>`;
  try {
    const ticketMap = new Map(); let added = 0; let skipped = 0;
    for (const batch of batches) {
      const projectId=document.querySelector("#import-target-project")?.value;
      if(!projectId)throw new Error("请先选择本批维修表所属的统一项目");
      const outcome = integrateImport(batch.payload, batch.file.name, batch.id, projectId);
      added += outcome.tickets; skipped += outcome.skipped;
      outcome.ticketMap.forEach((ticketId, key) => ticketMap.set(key, ticketId));
    }
    await saveData();
    let uploaded = 0; let uploadFailed = 0;
    for (const photo of importQueue.photos) {
      const ticketId = ticketMap.get(photo.targetKey);
      if (!ticketId) { uploadFailed += 1; continue; }
      try { await photoStore.add(ticketId, photo.file); uploaded += 1; }
      catch { uploadFailed += 1; }
    }
    importQueue = { workbooks: [], photos: [] };
    updateImportReview();
    document.querySelector("#import-result").innerHTML = `<div class="notice" style="background:var(--success-soft);color:#31674c"><div><strong>导入完成</strong><br/>新增 ${added} 条售后单${skipped ? `，识别到 ${skipped} 条重复问题` : ""}；已上传 ${uploaded} 张现场照片${uploadFailed ? `，${uploadFailed} 张照片上传失败` : ""}。</div></div>`;
    toast(uploadFailed ? "售后单已导入，部分照片未上传" : "售后单和照片已导入");
  } catch (error) {
    result.innerHTML = `<div class="notice" style="background:var(--red-soft);color:#98453e"><div><strong>暂时无法导入</strong><br/>${escape(error.message || "请稍后重试")}</div></div>`;
    if (confirmButton) { confirmButton.disabled = false; confirmButton.textContent = "确认导入"; }
  }
}
function integrateImport(payload,sourceName,batchId,projectId){const project=projectFor(projectId);if(!project)throw new Error('项目不存在');let added=0,skipped=0;const ticketMap=new Map();payload.tickets.forEach((row,index)=>{const previewKey=`${batchId}:${index}`,sourceKey=`${sourceName}:${row._sheetRow??index}`;const duplicate=data.tickets.find(t=>t.projectId===projectId&&t.importSourceKey===sourceKey);if(duplicate){skipped++;ticketMap.set(previewKey,duplicate.id);return;}const {_sheetRow,...fields}=row;const ticket={...fields,id:nextTicketCode(projectId),projectId,importSourceKey:sourceKey,source:`导入：${sourceName}`,partsUsed:[],history:[{at:now(),action:'维修表导入',note:sourceName}]};data.tickets.push(ticket);ticketMap.set(previewKey,ticket.id);added++;});return {projectName:project.name,tickets:added,skipped,ticketMap};}
async function parseXlsx(file) { const entries = await readZipEntries(new Uint8Array(await file.arrayBuffer())); const shared = entries.get("xl/sharedStrings.xml") ? parseSharedStrings(decodeText(entries.get("xl/sharedStrings.xml"))) : []; const sheetName = [...entries.keys()].find((name) => /^xl\/worksheets\/sheet\d+\.xml$/.test(name)); if (!sheetName) throw new Error("未找到工作表"); const grid = parseSheet(decodeText(entries.get(sheetName)), shared); const payload = parseRepairGrid(grid); const embeddedPhotos = extractEmbeddedPhotos(entries, sheetName); payload.embeddedPhotos = embeddedPhotos.map((photo) => ({ ...photo, ticketIndex: payload.tickets.findIndex((ticket) => ticket._sheetRow === photo.sheetRow) })); return payload; }
async function parseCsv(file) { const text = await file.text(); const lines = text.replace(/^\uFEFF/, "").trim().split(/\r?\n/).map((line) => line.split(",").map((cell) => cell.trim())); const header = lines[0] || []; const get = (row, names) => row[header.findIndex((item) => names.includes(item))] || ""; const tickets = lines.slice(1).filter((row) => row.some(Boolean)).map((row) => ({ date: normalizeDate(get(row, ["日期", "反馈日期"])), product: get(row, ["名称", "产品名称"]) || "未填写", description: get(row, ["故障描述", "问题描述"]), category: "其他", causeAnalysis: "待确认", causeCategory: "待确认", solution: "", handling: "", followUpDate: "", followUpResult: "", summary: "", repeated: "否", needsImprovement: "否", suggestion: "", owner: get(row, ["负责人", "跟进人"]), stage: "接收反馈", dueDate: "", notes: "" })); if (!tickets.length) throw new Error("CSV 中没有识别到故障描述"); return { project: { name: get(lines[1] || [], ["项目名称"]) || "未命名项目", contractNo: get(lines[1] || [], ["合同编号"]), contact: "", phone: "", address: "", owner: "", business: "", country: "中国", warranty: "" }, tickets }; }
function parseRepairGrid(grid) { const at = (row, column) => grid.get(`${row},${column}`) || ""; let headerRow = 0; for (let row = 1; row < 50; row += 1) if (String(at(row, 1)).includes("序号") && [...Array(12)].some((_, col) => String(at(row, col + 1)).includes("故障描述"))) { headerRow = row; break; } if (!headerRow) throw new Error("未识别到“序号 / 故障描述”明细表头"); const headers = {}; for (let column = 1; column < 20; column += 1) headers[at(headerRow, column)] = column; const col = (keyword, fallback) => Object.entries(headers).find(([key]) => String(key).includes(keyword))?.[1] || fallback; const seqCol = col("序号", 1), dateCol = col("日期", 2), nameCol = col("名称", 3), descCol = col("故障描述", 4); const tickets = []; for (let row = headerRow + 1; row < headerRow + 150; row += 1) { const sequence = at(row, seqCol); const description = at(row, descCol); if (!sequence && !description) { if (tickets.length) break; continue; } if (!description) continue; const product = at(row, nameCol) || "未填写"; tickets.push({ date: normalizeDate(at(row, dateCol)), product, description, category: guessCategory(product), causeAnalysis: "待确认", causeCategory: "待确认", solution: "", handling: "", followUpDate: "", followUpResult: "", summary: "", repeated: /再次反馈|反复|重复/.test(description) ? "是" : "否", needsImprovement: "否", suggestion: "", owner: at(2, 7) || "", stage: "接收反馈", dueDate: "", notes: "", _sheetRow: row }); }
  if (!tickets.length) throw new Error("未识别到维修问题明细");
  return { project: { name: at(2, 4) || "未命名项目", contractNo: at(1, 10), contact: at(3, 7), phone: String(at(3, 9) || ""), address: at(3, 4), owner: at(2, 7), business: at(2, 9), country: "中国", warranty: at(2, 10) }, tickets };
}
function guessCategory(product) { if (/灯|电|机|屏|传感|音响/.test(product)) return "电器类"; if (/蹦床|滑梯|网|架/.test(product)) return "主体类"; if (/软包|地垫|海绵/.test(product)) return "软包类"; if (/螺丝|五金|配件/.test(product)) return "配件"; return "其他"; }
function normalizeDate(value) { if (typeof value === "number" || /^\d{5}$/.test(String(value))) { const epoch = new Date(Date.UTC(1899, 11, 30)); epoch.setUTCDate(epoch.getUTCDate() + Number(value)); return epoch.toISOString().slice(0, 10); } const text = String(value || "").trim(); if (!text) return ""; const match = text.match(/(\d{2,4})[\/-](\d{1,2})[\/-](\d{1,2})/); if (!match) return text; const year = match[1].length === 2 ? 2000 + Number(match[1]) : Number(match[1]); return `${year}-${String(match[2]).padStart(2, "0")}-${String(match[3]).padStart(2, "0")}`; }
function decodeText(bytes) { return new TextDecoder("utf-8").decode(bytes); }
function parseSharedStrings(xml) { const doc = new DOMParser().parseFromString(xml, "application/xml"); return [...doc.querySelectorAll("si")].map((item) => [...item.querySelectorAll("t")].map((node) => node.textContent || "").join("")); }
function parseSheet(xml, sharedStrings) { const doc = new DOMParser().parseFromString(xml, "application/xml"); const grid = new Map(); for (const cell of doc.querySelectorAll("sheetData c")) { const ref = cell.getAttribute("r") || ""; const match = ref.match(/([A-Z]+)(\d+)/); if (!match) continue; const column = columnNumber(match[1]); const row = Number(match[2]); const type = cell.getAttribute("t"); let value = cell.querySelector("v")?.textContent || ""; if (type === "s") value = sharedStrings[Number(value)] || ""; else if (type === "inlineStr") value = [...cell.querySelectorAll("is t")].map((node) => node.textContent || "").join(""); grid.set(`${row},${column}`, value); } return grid; }
function zipPath(base, target) { const parts = base.split("/"); for (const segment of target.split("/")) { if (!segment || segment === ".") continue; if (segment === "..") parts.pop(); else parts.push(segment); } return parts.join("/"); }
function relationshipTargets(xml) { const doc = new DOMParser().parseFromString(xml, "application/xml"); return new Map([...doc.querySelectorAll("Relationship")].map((item) => [item.getAttribute("Id"), item.getAttribute("Target")])); }
function mediaType(name) { const extension = name.split(".").pop()?.toLowerCase(); return ({ png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", bmp: "image/bmp" })[extension] || "application/octet-stream"; }
function extractEmbeddedPhotos(entries, sheetName) {
  const worksheet = new DOMParser().parseFromString(decodeText(entries.get(sheetName)), "application/xml");
  const drawing = worksheet.querySelector("drawing");
  const drawingId = drawing?.getAttribute("r:id") || drawing?.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
  const sheetFile = sheetName.split("/").pop();
  const sheetRelationships = entries.get(`xl/worksheets/_rels/${sheetFile}.rels`);
  if (!drawingId || !sheetRelationships) return [];
  const drawingTarget = relationshipTargets(decodeText(sheetRelationships)).get(drawingId);
  if (!drawingTarget) return [];
  const drawingPath = zipPath("xl/worksheets", drawingTarget);
  const drawingDirectory = drawingPath.slice(0, drawingPath.lastIndexOf("/"));
  const drawingRelationships = entries.get(`${drawingDirectory}/_rels/${drawingPath.split("/").pop()}.rels`);
  const drawingBytes = entries.get(drawingPath);
  if (!drawingBytes || !drawingRelationships) return [];
  const relationships = relationshipTargets(decodeText(drawingRelationships));
  const drawingDocument = new DOMParser().parseFromString(decodeText(drawingBytes), "application/xml");
  return [...drawingDocument.querySelectorAll("twoCellAnchor, oneCellAnchor")].flatMap((anchor) => {
    const blip = anchor.querySelector("blip");
    const embed = blip?.getAttribute("r:embed") || blip?.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "embed");
    const target = relationships.get(embed);
    const sheetRow = Number(anchor.querySelector("from row")?.textContent || -1) + 1;
    const path = target ? zipPath(drawingDirectory, target) : "";
    const bytes = entries.get(path);
    if (!bytes || sheetRow < 1) return [];
    const name = path.split("/").pop() || "现场照片";
    return [{ file: new File([bytes], name, { type: mediaType(name) }), sheetRow, source: "Excel 内嵌照片" }];
  });
}
function columnNumber(name) { return [...name].reduce((value, char) => value * 26 + char.charCodeAt(0) - 64, 0); }
async function readZipEntries(bytes) { const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength); let end = -1; for (let index = bytes.length - 22; index >= Math.max(0, bytes.length - 65557); index -= 1) if (view.getUint32(index, true) === 0x06054b50) { end = index; break; } if (end < 0) throw new Error("不是有效的 XLSX 文件"); const count = view.getUint16(end + 10, true); let offset = view.getUint32(end + 16, true); const entries = new Map(); for (let i = 0; i < count; i += 1) { if (view.getUint32(offset, true) !== 0x02014b50) throw new Error("XLSX 压缩目录读取失败"); const method = view.getUint16(offset + 10, true), compressedSize = view.getUint32(offset + 20, true), nameLength = view.getUint16(offset + 28, true), extraLength = view.getUint16(offset + 30, true), commentLength = view.getUint16(offset + 32, true), localOffset = view.getUint32(offset + 42, true); const name = decodeText(bytes.slice(offset + 46, offset + 46 + nameLength)); if (view.getUint32(localOffset, true) !== 0x04034b50) throw new Error("XLSX 文件条目读取失败"); const localNameLength = view.getUint16(localOffset + 26, true), localExtraLength = view.getUint16(localOffset + 28, true), start = localOffset + 30 + localNameLength + localExtraLength; const payload = bytes.slice(start, start + compressedSize); if (method === 0) entries.set(name, payload); else if (method === 8 && "DecompressionStream" in window) { const stream = new Blob([payload]).stream().pipeThrough(new DecompressionStream("deflate-raw")); entries.set(name, new Uint8Array(await new Response(stream).arrayBuffer())); } else throw new Error("此浏览器暂不支持读取该 Excel 文件"); offset += 46 + nameLength + extraLength + commentLength; } return entries; }

function formatBytes(bytes) { return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`; }
function exportBackup() { const content = JSON.stringify({ exportedAt: now(), system: "儿童游乐设备售后管理系统本地版", data }, null, 2); const url = URL.createObjectURL(new Blob([content], { type: "application/json" })); const link = document.createElement("a"); link.href = url; link.download = `售后工作台本地备份_${today()}.json`; link.click(); URL.revokeObjectURL(url); toast("已导出售后资料副本（不含附件文件）"); }

document.addEventListener("click", (event) => { const routeNode = event.target.closest("[data-route]"); if (routeNode && !routeNode.dataset.route) return; });
window.addEventListener("hashchange", () => { const [nextRoute, ticketId] = window.location.hash.slice(1).split("/"); if (nextRoute) { route = nextRoute; currentTicketId = ticketIdMigration.get(ticketId) || ticketId || null; render(); } });
const initial = window.location.hash.slice(1); if (initial) { const [nextRoute, ticketId] = initial.split("/"); route = nextRoute || "dashboard"; currentTicketId = ticketIdMigration.get(ticketId) || ticketId || null; }
render();
loadCloudData();
