window.AFTER_SALES_CONFIG = {
  enabled: true,
  apiBase: "",
};
