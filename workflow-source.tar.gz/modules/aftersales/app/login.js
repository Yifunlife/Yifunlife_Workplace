const form = document.querySelector("#login-form");
const error = document.querySelector("#login-error");
const button = form.querySelector("button");
const cloudUrl = "https://yifun-aftersales.yifunlife.workers.dev";

if (window.location.protocol === "file:") {
  error.textContent = "正在打开云端工作台…";
  window.location.replace(`${cloudUrl}/login`);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  error.textContent = "";
  button.disabled = true;
  button.textContent = "正在验证…";
  const payload = Object.fromEntries(new FormData(form));
  try {
    const response = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error("账号或密码不正确，请重试。");
    window.location.assign("/");
  } catch (reason) {
    error.textContent = reason.message === "Failed to fetch" ? "无法连接云端工作台，请检查网络后重试。" : (reason.message || "暂时无法登录，请稍后重试。");
    button.disabled = false;
    button.textContent = "进入工作台";
  }
});
