/** Preserve the R2 interface while running the original modules in Containers. */
export function objectBucket(local: any, env: any, store: string): any {
  if (!env.YIFUN_R2_GATEWAY) return local;
  if (env.YIFUN_R2_GATEWAY !== 'http://files.yifun.internal') throw new Error('Invalid private file binding');
  const call = async (key: string, method = 'GET', body?: any, type?: string) => {
    if (!key || key.startsWith('/') || key.split('/').includes('..') || key.includes('\\')) throw new Error('Invalid object key');
    return fetch(`${env.YIFUN_R2_GATEWAY}/${store}/${key.split('/').map(encodeURIComponent).join('/')}`,
      { method, body, headers: type ? { 'Content-Type': type } : undefined });
  };
  return {
    async get(key: string) {
      const response = await call(key);
      if (response.status === 404) return null;
      if (!response.ok) throw new Error('Private object read failed');
      const contentType = response.headers.get('Content-Type') || 'application/octet-stream';
      return {
        body: response.body, size: Number(response.headers.get('Content-Length') || 0),
        httpEtag: response.headers.get('ETag') || '', httpMetadata: { contentType },
        text: () => response.text(), json: () => response.json(), arrayBuffer: () => response.arrayBuffer(),
        writeHttpMetadata(headers: Headers) { headers.set('Content-Type', contentType); }
      };
    },
    async put(key: string, body: any, options?: any) {
      const response = await call(key, 'PUT', body, options?.httpMetadata?.contentType || 'application/octet-stream');
      if (!response.ok) throw new Error('Private object save failed');
    },
    async delete(key: string) {
      const response = await call(key, 'DELETE');
      if (!response.ok) throw new Error('Private object delete failed');
    }
  };
}
