import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { cloudflare } from "@cloudflare/vite-plugin";

export default defineConfig({
  base: process.env.YIFUN_MODULE_BASE ? process.env.YIFUN_MODULE_BASE+"/" : "/",
  plugins: [react(), cloudflare()],
});
