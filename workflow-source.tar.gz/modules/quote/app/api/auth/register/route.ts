export async function POST() { return Response.json({error:"员工账号请在 Workplace 由管理员建立"},{status:403}); }
