// Local Cloudflare runtime tests. No real login credentials or cloud requests.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { generateKeyPair, exportJWK, SignJWT } from 'jose';

const root = path.resolve(import.meta.dirname, '..');
const require = createRequire(import.meta.url);
const { Miniflare } = require(require.resolve('miniflare', { paths: [fs.realpathSync(path.join(root, 'modules/quote/node_modules/wrangler'))] }));
const build = process.argv[2] || '/tmp/yifun-cloud-worker-check';
const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'yifun-gateway-'));
for (const name of fs.readdirSync(build)) if (name.endsWith('.js') || name.endsWith('.txt')) fs.copyFileSync(path.join(build, name), path.join(directory, name));
fs.writeFileSync(path.join(directory, 'worker.js'), `
import gateway, {WorkplaceContainer} from './container-worker.js';
import {DurableObject} from 'cloudflare:workers';
export class FakeContainer extends DurableObject {
  fetch(request) {if(new URL(request.url).pathname==='/api/auth/session'){const email=request.headers.get('Cookie')?.replace('fixture=','');return Response.json({authenticated:!!email,user:email?{email}:null});} return Response.json({identity:request.headers.get('X-Yifun-Verified-Email'),bridge:request.headers.get('X-Workspace-Bridge')});}
}
export default {async fetch(request,env) {
  const url=new URL(request.url);
  if(url.pathname.startsWith('/test-module/')) {
    const name=url.pathname.split('/')[2];
    const moduleURL=new URL('/modules/'+name+'/sample',request.url);
    const proxy={startAndWaitForPorts:async()=>{},containerFetch:async(req,port)=>Response.json({url:req.url,port,fileUrl:'/api/files/demo',note:'/api/this-is-text'})};
    return WorkplaceContainer.prototype.fetch.call(proxy,new Request(moduleURL));
  }
  if(url.pathname.startsWith('/test-html/')) {
    const name=url.pathname.split('/')[2];
    const proxy={startAndWaitForPorts:async()=>{},containerFetch:async()=>new Response('<html><head><title>Fixture</title></head><body><img src="/api/image/demo"><a href="/products">Products</a></body></html>',{headers:{'Content-Type':'text/html'}})};
    return WorkplaceContainer.prototype.fetch.call(proxy,new Request(new URL('/modules/'+name+'/',request.url)));
  }
  if(url.pathname.startsWith('/test-r2/')) {
    const objectURL=new URL('/objects/operations/demo-file',request.url);
    return WorkplaceContainer.outboundByHost['objects.yifun.internal'](new Request(objectURL,request),env);
  }
  if(url.pathname.startsWith('/test-native/')){url.pathname=url.pathname.slice('/test-native'.length);return gateway.fetch(new Request(url,request),{...env,AUTH_MODE:'password'});}
  return gateway.fetch(request,env);
}};
`);
const issuer = 'https://fixture.cloudflareaccess.com';
const origin = 'https://workplace.fixture.invalid';
const { publicKey, privateKey } = await generateKeyPair('RS256');
const jwk = { ...await exportJWK(publicKey), kid: 'local-test-key', alg: 'RS256', use: 'sig' };
const outboundService = async request => {
  if (request.url !== issuer + '/cdn-cgi/access/certs') throw new Error('Unexpected external request in local test');
  return new Response(JSON.stringify({keys:[jwk]}), {headers:{'Content-Type':'application/json'}});
};
let source = fs.readFileSync(path.join(directory,'container-worker.js'),'utf8');
source = source.replace(/import browserSource from "([^"]+)";/, (_, file) => 'const browserSource='+JSON.stringify(fs.readFileSync(path.join(directory,file),'utf8'))+';');
source = source.replace(/export \{\s*BusinessDatabase,\s*ContainerProxy,\s*WorkplaceContainer,\s*container_worker_default as default\s*\};/, '');
let wrapper=fs.readFileSync(path.join(directory,'worker.js'),'utf8');
wrapper=wrapper.replace("import gateway, {WorkplaceContainer} from './container-worker.js';", 'const gateway=container_worker_default;').replace("import {DurableObject} from 'cloudflare:workers';",'');
const mf = new Miniflare({ script: source+'\n'+wrapper, modules: true,
  compatibilityDate: '2026-05-15', compatibilityFlags: ['nodejs_compat'], outboundService,
  durableObjects: { WORKPLACE_CONTAINER: { className: 'FakeContainer', useSQLite: true } }, r2Buckets: ['CORE_FILES'],
  bindings: { PUBLIC_ORIGIN: origin, OWNER_EMAIL: 'owner@example.invalid', VIEWER_EMAILS: 'viewer@example.invalid', ACCESS_ISSUER: issuer, ACCESS_AUD: 'local-test-audience' } });
const token = email => new SignJWT({email}).setProtectedHeader({alg:'RS256',kid:jwk.kid}).setIssuer(issuer).setAudience('local-test-audience').setIssuedAt().setExpirationTime('2m').sign(privateKey);
try {
  assert.equal((await mf.dispatchFetch(origin+'/api/auth/session')).status,401);
  assert.equal((await mf.dispatchFetch(origin+'/api/internal/session')).status,404);
  const viewer = await token('viewer@example.invalid');
  const owner = await token('owner@example.invalid');
  const denied = await token('unlisted@example.invalid');
  assert.equal((await mf.dispatchFetch(origin+'/',{headers:{'Cf-Access-Jwt-Assertion':denied}})).status,403);
  assert.equal((await mf.dispatchFetch(origin+'/api/action/create-po',{method:'POST',headers:{'Cf-Access-Jwt-Assertion':viewer},body:'{}'})).status,403);
  const response = await mf.dispatchFetch(origin+'/',{headers:{'Cf-Access-Jwt-Assertion':owner,'X-Yifun-Verified-Email':'unlisted@example.invalid','X-Workspace-Bridge':'spoofed'}});
  assert.equal(response.status,200);
  assert.deepEqual(await response.json(),{identity:'owner@example.invalid',bridge:null});
  for(const [name,port] of [['quote',8991],['procurement',8992],['aftersales',8993]]) {
    const response = await mf.dispatchFetch(origin+'/test-module/'+name);
    const payload = await response.json();
    assert.equal(payload.port,port);
    assert.equal(new URL(payload.url).pathname,'/sample');
    assert.equal(payload.fileUrl,'/modules/'+name+'/api/files/demo');
    assert.equal(payload.note,'/api/this-is-text');
    const html=await (await mf.dispatchFetch(origin+'/test-html/'+name)).text();
    assert.ok(html.includes('/modules/'+name+'/cloud-entry.js'));
    assert.ok(html.includes('/modules/'+name+'/api/image/demo'));
  }
  assert.equal((await mf.dispatchFetch(origin+'/test-r2/file',{method:'PUT',headers:{'Content-Type':'application/pdf'},body:'synthetic file bytes'})).status,204);
  const file=await mf.dispatchFetch(origin+'/test-r2/file');
  assert.equal(file.headers.get('Content-Type'),'application/pdf');
  assert.equal(await file.text(),'synthetic file bytes');
  const native = path=>origin+'/test-native'+path;
  assert.equal((await mf.dispatchFetch(native('/modules/quote/'))).status,401);
  assert.equal((await mf.dispatchFetch(native('/api/view/overview'))).status,401);
  assert.equal((await mf.dispatchFetch(native('/password-recovery'))).status,200);
  assert.equal((await mf.dispatchFetch(native('/password-recovery.js'))).status,200);
  assert.equal((await mf.dispatchFetch(native('/read-cache.js'))).status,200);
  const landing=await mf.dispatchFetch(native('/'),{headers:{'X-Yifun-Verified-Email':'owner@example.invalid','X-Workspace-Bridge':'spoofed'}});
  assert.deepEqual(await landing.json(),{identity:null,bridge:null});
  const nativeOwner=await mf.dispatchFetch(native('/api/action/customers'),{method:'POST',headers:{Cookie:'fixture=owner@example.invalid'},body:'{}'});
  assert.equal(nativeOwner.status,200);
  assert.equal((await nativeOwner.json()).identity,'owner@example.invalid');
  assert.equal((await mf.dispatchFetch(native('/api/action/customers'),{method:'POST',headers:{Cookie:'fixture=viewer@example.invalid'},body:'{}'})).status,403);
  assert.equal((await mf.dispatchFetch(native('/modules/quote/'),{headers:{Cookie:'fixture=viewer@example.invalid'}})).status,200);
  assert.equal((await mf.dispatchFetch(native('/modules/quote/'),{headers:{Cookie:'fixture=unlisted@example.invalid'}})).status,403);
  assert.equal((await mf.dispatchFetch(native('/api/auth/recover'),{method:'POST',headers:{Cookie:'fixture=owner@example.invalid'},body:'{}'})).status,404);
  assert.equal((await mf.dispatchFetch(native('/account-recovery'))).status,401);
  assert.equal((await mf.dispatchFetch(native('/account-recovery'),{headers:{'Cf-Access-Jwt-Assertion':denied}})).status,403);
  const recovery=await mf.dispatchFetch(native('/account-recovery'),{headers:{'Cf-Access-Jwt-Assertion':owner}});
  assert.equal(recovery.status,200);
  assert.equal(recovery.headers.get('Referrer-Policy'),'same-origin');
  assert.ok((await recovery.text()).includes('owner@example.invalid'));
  const wrongOrigin=await mf.dispatchFetch(native('/account-recovery/reset'),{method:'POST',headers:{'Cf-Access-Jwt-Assertion':owner,'Content-Type':'application/x-www-form-urlencoded',Origin:'https://evil.fixture.invalid'},body:'password=fixture-only&confirm=fixture-only'});
  assert.ok((await wrongOrigin.text()).includes('提交来源校验失败'));
  const restored=await mf.dispatchFetch(native('/account-recovery/reset'),{redirect:'manual',method:'POST',headers:{'Cf-Access-Jwt-Assertion':owner,'Content-Type':'application/x-www-form-urlencoded',Origin:origin},body:'password=fixture-only&confirm=fixture-only'});
  assert.equal(restored.status,303);
  assert.equal(restored.headers.get('Location'),'/');
  console.log('PASS: verified-email allowlist, JWT enforcement, spoofed-header rejection, read-only writes, all module mounts and private R2 file round trip and direct-password session gateway');
} finally { await mf.dispose(); fs.rmSync(directory,{recursive:true,force:true}); }
